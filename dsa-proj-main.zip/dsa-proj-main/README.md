# DSA-Powered Document Search & Learning Assistant

A C++/Qt application demonstrating Data Structures and Algorithms (DSA) for educational document search, summarization, keyword extraction, question generation, and topic relationship visualization.

## Features

- **File Loading**: Load and process multiple `.txt` text files and `.pdf` documents
- **PDF Support**: Extract text from PDF files using `pdftotext` or macOS `textutil`
- **DSA-Based Search Engine**:
  - **Trie**: Efficient prefix search and autocomplete
  - **Inverted Index**: Fast document retrieval using hash maps
  - **TF-IDF Ranking**: Relevance scoring for search results
- **Extractive Summarization**: TextRank algorithm (graph-based PageRank style)
- **Keyword Extraction**: Frequency analysis with min-heap/priority queue
- **Question Generation**: Rule-based generation of:
  - Fill-in-the-blank questions
  - True/False questions
  - Short answer questions
  - Multiple choice questions (MCQ)
- **Topic Relation Graph**: Adjacency list representation with text-based visualization
- **Qt Widgets GUI**: Clean, minimal interface with organized panels

## Requirements

- **C++17** compatible compiler (GCC 7+, Clang 5+, MSVC 2017+)
- **CMake** 3.16 or higher
- **Qt6** Widgets (or Qt5 as fallback)
- **PDF Support (Optional)**: For PDF file support, install `pdftotext`:
  - **macOS**: `brew install poppler` (or use built-in `textutil`)
  - **Linux**: `sudo apt-get install poppler-utils` or `sudo yum install poppler-utils`
  - **Windows**: Install poppler from [poppler-windows](https://github.com/oschwartz10612/poppler-windows)

### Installing Qt6 on macOS

```bash
brew install qt6
```

### Installing Qt6 on Linux (Ubuntu/Debian)

```bash
sudo apt-get install qt6-base-dev
```

### Installing Qt6 on Windows

Download and install from [Qt Official Website](https://www.qt.io/download)

## Build Instructions

1. Clone or navigate to the project directory:
```bash
cd dsa_proj
```

2. Create build directory:
```bash
mkdir build
cd build
```

3. Configure with CMake:
```bash
cmake ..
```

4. Build the project:
```bash
make
```

On Windows (with Visual Studio):
```bash
cmake .. -G "Visual Studio 17 2022"
cmake --build . --config Release
```

5. Run the application:
```bash
./dsa_assistant
```

On Windows:
```bash
Release\dsa_assistant.exe
```

## Usage

1. **Load Documents**: Click "Load Files..." button or use File → Load Documents menu to select `.txt` or `.pdf` files
2. **Search**: Enter a query in the search box and click "Search" or press Enter
3. **View Results**: Search results appear in the left panel with relevance scores and snippets
4. **Generate Summary**: Select a document from search results, then use Analyze → Generate Summary
5. **Extract Keywords**: Use Analyze → Extract Keywords to see top keywords from the selected document
6. **Generate Questions**: Use Analyze → Generate Questions to create educational questions
7. **View Topic Graph**: Use Analyze → Show Topic Graph to visualize keyword relationships

## Project Structure

```
dsa_proj/
├── CMakeLists.txt          # Build configuration
├── README.md               # This file
├── src/
│   ├── main.cpp            # Application entry point
│   ├── gui/                # GUI components
│   │   ├── MainWindow.h
│   │   └── MainWindow.cpp
│   ├── core/               # Core functionality
│   │   ├── DocumentProcessor.h/cpp
│   │   ├── SearchEngine.h/cpp
│   │   ├── Summarizer.h/cpp
│   │   ├── KeywordExtractor.h/cpp
│   │   ├── QuestionGenerator.h/cpp
│   │   └── TopicGraph.h/cpp
│   └── ds/                 # Data structures
│       ├── Trie.h/cpp
│       ├── InvertedIndex.h/cpp
│       ├── TFIDF.h/cpp
│       └── TextRank.h/cpp
├── include/
│   └── types.h             # Common data structures
├── test/
│   └── sample_docs/        # Sample text files for testing
└── docs/
    ├── class_diagram.md
    └── module_diagram.md
```

## Algorithms Implemented

### Data Structures
- **Trie**: Prefix tree for efficient string matching
- **Inverted Index**: Hash map-based term-to-document mapping
- **Min-Heap (Priority Queue)**: For top-K keyword extraction
- **Adjacency List**: Graph representation for topic relationships

### Algorithms
- **TF-IDF**: Term Frequency × Inverse Document Frequency for ranking
- **TextRank**: Graph-based sentence ranking (similar to PageRank)
- **BFS/DFS**: Graph traversal for topic visualization
- **Cosine Similarity**: For sentence similarity in TextRank

## Technical Details

- **No AI/ML APIs**: All algorithms implemented from scratch using pure DSA
- **STL Containers Only**: Uses standard library containers (vector, unordered_map, priority_queue, etc.)
- **Qt Widgets**: Traditional widget-based UI (not QML)
- **Modular Architecture**: Separation of concerns with clear module boundaries

## Limitations

- PDF support requires `pdftotext` or `textutil` (macOS) to be installed
- Text-based graph visualization (advanced visualization is optional)
- Simple question generation templates (no AI-based generation)

## Example Test Files

Sample documents are provided in `test/sample_docs/`:
- `algo_intro.txt`: Introduction to algorithms
- `data_structures.txt`: Data structures overview
- `graph_theory.txt`: Graph theory concepts

## Contributing

This is an educational project demonstrating DSA concepts. Contributions and improvements are welcome!

## License

This project is provided for educational purposes.

