# Class Diagram

## Data Structures Module (`src/ds/`)

```
Trie
├── Node (private struct)
│   ├── children: unordered_map<char, Node*>
│   └── isEnd: bool
├── root: Node*
├── insert(word: string)
├── search(word: string): bool
└── prefixMatch(prefix: string): vector<string>

InvertedIndex
├── index: unordered_map<string, vector<pair<int, int>>>
├── addTerm(term, docId, position)
├── find(term): vector<pair<int, int>>
├── getDocuments(term): vector<int>
└── contains(term): bool

TFIDF
├── documents: vector<Document>
├── index: InvertedIndex*
├── totalDocs: int
├── computeTF(term, docId): double
├── computeIDF(term): double
├── computeScore(term, docId): double
├── rank(queryTerms, candidateDocs): vector<pair<int, double>>
└── getDocumentScore(queryTerms, docId): double

TextRank
├── cosineSimilarity(vec1, vec2): double
├── buildWordVector(sentence): unordered_map<string, int>
├── tokenize(sentence): vector<string>
└── compute(sentences): vector<pair<int, double>>
```

## Core Components Module (`src/core/`)

```
DocumentProcessor
├── stopwords: unordered_set<string>
├── initializeStopwords()
├── isStopword(word): bool
├── normalizeWord(word): string
├── loadFile(filepath, docId): Document
├── tokenize(text): vector<string>
├── extractSentences(text): vector<string>
└── buildTermFreq(tokens): unordered_map<string, int>

SearchEngine
├── documents: vector<Document>
├── trie: Trie
├── index: InvertedIndex
├── tfidf: TFIDF*
├── processor: DocumentProcessor
├── addDocument(doc)
├── search(query): vector<QueryResult>
├── getSuggestions(prefix): vector<string>
├── getDocument(docId): Document
└── clear()

Summarizer
├── textRank: TextRank
└── summarize(doc/sentences, numSentences): string

KeywordExtractor
├── KeywordPair (struct)
│   ├── freq: int
│   └── keyword: string
└── extract(doc/termFreq, topK): vector<string>

QuestionGenerator
├── extractor: KeywordExtractor
├── generateFillBlank(...): vector<Question>
├── generateTrueFalse(...): vector<Question>
├── generateShortAnswer(...): vector<Question>
├── generateMCQ(...): vector<Question>
├── sentenceToQuestion(sentence): string
├── generateDistractors(...): vector<string>
└── generate(doc, type, numQuestions): vector<Question>

TopicGraph
├── graph: unordered_map<string, vector<string>>
├── coOccur(topic1, topic2, documents): bool
├── build(documents, keywords)
├── getNeighbors(topic): vector<string>
├── getTopics(): vector<string>
├── visualize(): string
└── clear()
```

## GUI Module (`src/gui/`)

```
MainWindow : QMainWindow
├── Core Components
│   ├── searchEngine: SearchEngine
│   ├── processor: DocumentProcessor
│   ├── summarizer: Summarizer
│   ├── extractor: KeywordExtractor
│   ├── questionGen: QuestionGenerator
│   └── topicGraph: TopicGraph
├── UI Components
│   ├── centralWidget: QWidget*
│   ├── mainLayout: QVBoxLayout*
│   ├── topLayout: QHBoxLayout*
│   ├── loadButton: QPushButton*
│   ├── searchInput: QLineEdit*
│   ├── searchButton: QPushButton*
│   ├── resultsDisplay: QTextEdit*
│   ├── summaryDisplay: QTextEdit*
│   ├── keywordsList: QListWidget*
│   ├── questionsList: QListWidget*
│   └── graphDisplay: QTextEdit*
├── setupUI()
├── setupMenus()
├── onLoadFiles() [slot]
├── onSearch() [slot]
├── onGenerateSummary() [slot]
├── onExtractKeywords() [slot]
├── onGenerateQuestions() [slot]
├── onShowGraph() [slot]
└── onAbout() [slot]
```

## Data Types (`include/types.h`)

```
Document
├── id: int
├── filename: string
├── content: string
├── sentences: vector<string>
├── termFreq: unordered_map<string, int>
└── tokens: vector<string>

QueryResult
├── docId: int
├── score: double
├── snippet: string
└── filename: string
│   └── operator<() (for sorting)

Question
├── type: string
├── question: string
├── options: vector<string>
└── answer: string
```

## Relationships

- `SearchEngine` uses: `Trie`, `InvertedIndex`, `TFIDF`, `DocumentProcessor`
- `TFIDF` uses: `Document`, `InvertedIndex`
- `TextRank` is standalone algorithm
- `Summarizer` uses: `TextRank`
- `KeywordExtractor` uses: `Document` (min-heap internally)
- `QuestionGenerator` uses: `KeywordExtractor`, `Document`
- `TopicGraph` uses: `Document` (adjacency list)
- `MainWindow` orchestrates all core components

