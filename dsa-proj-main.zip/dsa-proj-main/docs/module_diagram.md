# Module Diagram

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Application Layer                       │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              MainWindow (Qt GUI)                       │  │
│  │  - File loading interface                             │  │
│  │  - Search interface                                   │  │
│  │  - Results display                                    │  │
│  │  - Analysis controls                                  │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                      Core Components Layer                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │DocumentProc. │  │SearchEngine  │  │ Summarizer   │     │
│  │- Load files  │  │- Integrate   │  │- TextRank    │     │
│  │- Tokenize    │  │  DS modules  │  │- Extract top │     │
│  │- Normalize   │  │- Search      │  │  sentences   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │KeywordExtr.  │  │QuestionGen.  │  │ TopicGraph   │     │
│  │- Frequency   │  │- Templates   │  │- Adjacency   │     │
│  │- Min-heap    │  │- Rule-based  │  │  list        │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    Data Structures Layer                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │     Trie     │  │InvertedIndex │  │    TFIDF     │     │
│  │- Prefix tree │  │- Hash map    │  │- TF × IDF    │     │
│  │- Autocomplete│  │- Term→docs   │  │- Ranking     │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
│  ┌──────────────┐                                          │
│  │   TextRank   │                                          │
│  │- Graph algo  │                                          │
│  │- PageRank    │                                          │
│  │- Similarity  │                                          │
│  └──────────────┘                                          │
└─────────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Document Storage                          │  │
│  │  - Document objects                                    │  │
│  │  - QueryResult objects                                 │  │
│  │  - Question objects                                     │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Module Dependencies

```
MainWindow
    │
    ├──► SearchEngine
    │       │
    │       ├──► Trie (prefix search)
    │       ├──► InvertedIndex (term lookup)
    │       ├──► TFIDF (ranking)
    │       └──► DocumentProcessor (tokenization)
    │
    ├──► DocumentProcessor (file loading)
    │
    ├──► Summarizer
    │       └──► TextRank (sentence scoring)
    │
    ├──► KeywordExtractor (frequency + heap)
    │
    ├──► QuestionGenerator
    │       └──► KeywordExtractor (for keywords)
    │
    └──► TopicGraph (adjacency list)
```

## Data Flow

### Search Flow
```
User Query
    ↓
MainWindow::onSearch()
    ↓
SearchEngine::search()
    ↓
    ├──► DocumentProcessor::tokenize() → query terms
    ├──► InvertedIndex::getDocuments() → candidate docs
    ├──► TFIDF::rank() → scored results
    └──► Generate snippets
    ↓
Display QueryResult[] in UI
```

### Summarization Flow
```
Selected Document
    ↓
Summarizer::summarize()
    ↓
TextRank::compute()
    ↓
    ├──► Build word vectors (sentence similarity)
    ├──► Build adjacency matrix
    ├──► Iterative PageRank → sentence scores
    └──► Extract top N sentences
    ↓
Display summary in UI
```

### Keyword Extraction Flow
```
Document
    ↓
KeywordExtractor::extract()
    ↓
    ├──► Get termFreq map
    ├──► Min-heap (priority_queue)
    │   └──► Maintain top K keywords
    └──► Sort by frequency
    ↓
Display keywords[] in UI
```

### Question Generation Flow
```
Document
    ↓
QuestionGenerator::generate()
    ↓
    ├──► KeywordExtractor::extract() → keywords
    ├──► Generate by type:
    │   ├──► Fill-blank: replace keyword with "___"
    │   ├──► True/False: statement + negation
    │   ├──► Short answer: convert to question form
    │   └──► MCQ: keyword + distractors
    ↓
Display Question[] in UI
```

### Topic Graph Flow
```
All Documents
    ↓
TopicGraph::build()
    ↓
    ├──► Extract keywords from all docs
    ├──► Check co-occurrence (documents sharing keywords)
    ├──► Build adjacency list (edges)
    └──► BFS traversal for visualization
    ↓
Display graph text in UI
```

## Module Responsibilities

| Module | Responsibility |
|--------|---------------|
| **MainWindow** | UI orchestration, user interaction, display results |
| **SearchEngine** | Coordinate search components (Trie, Index, TFIDF) |
| **DocumentProcessor** | File I/O, text normalization, tokenization |
| **Summarizer** | TextRank algorithm wrapper |
| **KeywordExtractor** | Frequency analysis, min-heap top-K selection |
| **QuestionGenerator** | Rule-based question templates |
| **TopicGraph** | Co-occurrence analysis, graph construction |
| **Trie** | Prefix matching, autocomplete |
| **InvertedIndex** | Term-to-document mapping |
| **TFIDF** | Relevance scoring algorithm |
| **TextRank** | Sentence ranking algorithm |

