#ifndef TYPES_H
#define TYPES_H

#include <string>
#include <vector>
#include <unordered_map>

/**
 * @brief Represents a document in the system
 */
struct Document {
    int id;                                         // Unique document identifier
    std::string filename;                           // Source filename
    std::string content;                            // Full text content
    std::vector<std::string> sentences;            // Extracted sentences
    std::unordered_map<std::string, int> termFreq; // Term frequency map
    std::vector<std::string> tokens;               // Tokenized words

    Document() : id(-1) {}
    Document(int id, const std::string& filename, const std::string& content)
        : id(id), filename(filename), content(content) {}
};

/**
 * @brief Represents a search query result
 */
struct QueryResult {
    int docId;           // Document ID
    double score;         // Relevance score (TF-IDF)
    std::string snippet; // Text snippet showing context
    std::string filename; // Document filename

    QueryResult() : docId(-1), score(0.0) {}
    QueryResult(int id, double s, const std::string& snip, const std::string& fn)
        : docId(id), score(s), snippet(snip), filename(fn) {}

    // For sorting by score (descending)
    bool operator<(const QueryResult& other) const {
        return score > other.score; // Higher score first
    }
};

/**
 * @brief Represents a generated question
 */
struct Question {
    std::string type;                    // Question type: "fill_blank", "true_false", "short_answer", "mcq"
    std::string question;                 // Question text
    std::vector<std::string> options;     // Answer options (for MCQ)
    std::string answer;                   // Correct answer

    Question() {}
    Question(const std::string& t, const std::string& q, const std::string& ans)
        : type(t), question(q), answer(ans) {}
    Question(const std::string& t, const std::string& q, const std::vector<std::string>& opts, const std::string& ans)
        : type(t), question(q), options(opts), answer(ans) {}
};

#endif // TYPES_H

