#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>
#include <QListWidget>
#include <QLabel>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QFileDialog>
#include <QMessageBox>
#include <QSplitter>
#include <QStatusBar>
#include <QKeySequence>
#include <QComboBox>
#include <QTimer>

#include "../core/SearchEngine.h"
#include "../core/DocumentProcessor.h"
#include "../core/Summarizer.h"
#include "../core/KeywordExtractor.h"
#include "../core/QuestionGenerator.h"
#include "../core/TopicGraph.h"
#include "../../include/types.h"

/**
 * @brief Main application window with Qt Widgets GUI
 * 
 * Provides interface for document loading, search, summarization,
 * keyword extraction, question generation, and topic graph visualization.
 */
class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    /**
     * @brief Slot for loading files button
     */
    void onLoadFiles();

    /**
     * @brief Slot for search button
     */
    void onSearch();

    /**
     * @brief Slot for generate summary action
     */
    void onGenerateSummary();

    /**
     * @brief Slot for extract keywords action
     */
    void onExtractKeywords();

    /**
     * @brief Slot for generate questions action
     */
    void onGenerateQuestions();

    /**
     * @brief Slot for show graph action
     */
    void onShowGraph();

    /**
     * @brief Slot for analyze selected document
     */
    void onAnalyzeDocument();

    /**
     * @brief Slot for document selection change
     */
    void onDocumentSelected();

    /**
     * @brief Slot for about dialog
     */
    void onAbout();

    /**
     * @brief Slot for search text change (triggers auto-search)
     */
    void onSearchTextChanged();

private:
    // Core components
    SearchEngine searchEngine;
    DocumentProcessor processor;
    Summarizer summarizer;
    KeywordExtractor extractor;
    QuestionGenerator questionGen;
    TopicGraph topicGraph;

    // UI Components
    QWidget* centralWidget;
    QVBoxLayout* mainLayout;
    
    // Top panel
    QHBoxLayout* topLayout;
    QPushButton* loadButton;
    QLineEdit* searchInput;
    QPushButton* searchButton;
    
    // Document selector
    QWidget* docSelectorPanel;
    QHBoxLayout* docSelectorLayout;
    QLabel* docSelectorLabel;
    QComboBox* docSelectorCombo;
    QPushButton* analyzeButton;
    
    // Middle section
    QSplitter* middleSplitter;
    QWidget* resultsPanel;
    QVBoxLayout* resultsLayout;
    QLabel* resultsLabel;
    QTextEdit* resultsDisplay;
    
    QWidget* summaryPanel;
    QVBoxLayout* summaryLayout;
    QLabel* summaryLabel;
    QTextEdit* summaryDisplay;
    
    // Bottom section - no longer using bottomLayout directly, using splitter
    QWidget* keywordsPanel;
    QVBoxLayout* keywordsLayout;
    QLabel* keywordsLabel;
    QListWidget* keywordsList;
    
    QWidget* questionsPanel;
    QVBoxLayout* questionsLayout;
    QLabel* questionsLabel;
    QTextEdit* questionsList;  // Changed from QListWidget to QTextEdit for better text display
    
    QWidget* graphPanel;
    QVBoxLayout* graphLayout;
    QLabel* graphLabel;
    QTextEdit* graphDisplay;
    
    // Menu bar (menuBar() method inherited from QMainWindow)
    QMenu* fileMenu;
    QMenu* searchMenu;
    QMenu* analyzeMenu;
    QMenu* helpMenu;
    
    // Current selected document
    int currentDocId;
    
    // Auto-search timer (delays search to avoid excessive queries while typing)
    QTimer* searchTimer;
    
    /**
     * @brief Initialize UI components
     */
    void setupUI();

    /**
     * @brief Setup menu bar
     */
    void setupMenus();

    /**
     * @brief Update status bar message
     * @param message Status message
     */
    void updateStatus(const QString& message);
};

#endif // MAINWINDOW_H

