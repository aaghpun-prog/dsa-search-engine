#include "MainWindow.h"
#include <QApplication>
#include <QFileInfo>
#include <QProcess>
#include <sstream>
#include <algorithm>
#include <iomanip>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), currentDocId(-1) {
    setupUI();
    setupMenus();
    
    // Initialize auto-search timer (500ms delay after typing stops)
    searchTimer = new QTimer(this);
    searchTimer->setSingleShot(true);
    searchTimer->setInterval(500); // Wait 500ms after user stops typing
    connect(searchTimer, &QTimer::timeout, this, &MainWindow::onSearch);
    
    updateStatus("Ready. Load documents to begin.");
}

MainWindow::~MainWindow() = default;

void MainWindow::setupUI() {
    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    
    mainLayout = new QVBoxLayout(centralWidget);
    
    // Top panel - File loading and search
    topLayout = new QHBoxLayout();
    loadButton = new QPushButton("Load Files...", this);
    searchInput = new QLineEdit(this);
    searchInput->setPlaceholderText("Enter search query...");
    searchButton = new QPushButton("Search", this);
    
    topLayout->addWidget(loadButton);
    topLayout->addWidget(searchInput);
    topLayout->addWidget(searchButton);
    
    // Document selector panel
    docSelectorPanel = new QWidget();
    docSelectorLayout = new QHBoxLayout(docSelectorPanel);
    docSelectorLabel = new QLabel("Select Document:", this);
    docSelectorCombo = new QComboBox(this);
    docSelectorCombo->setMinimumWidth(300);
    docSelectorCombo->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    analyzeButton = new QPushButton("Analyze Selected Document", this);
    docSelectorLayout->addWidget(docSelectorLabel);
    docSelectorLayout->addWidget(docSelectorCombo);
    docSelectorLayout->addWidget(analyzeButton);
    docSelectorLayout->addStretch();
    
    connect(loadButton, &QPushButton::clicked, this, &MainWindow::onLoadFiles);
    connect(searchButton, &QPushButton::clicked, this, &MainWindow::onSearch);
    connect(searchInput, &QLineEdit::returnPressed, this, &MainWindow::onSearch);
    connect(searchInput, &QLineEdit::textChanged, this, &MainWindow::onSearchTextChanged);
    connect(analyzeButton, &QPushButton::clicked, this, &MainWindow::onAnalyzeDocument);
    connect(docSelectorCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), 
            this, &MainWindow::onDocumentSelected);
    
    mainLayout->addLayout(topLayout);
    mainLayout->addWidget(docSelectorPanel);
    
    // Middle section - Results and Summary
    middleSplitter = new QSplitter(Qt::Horizontal, this);
    
    // Left: Search Results
    resultsPanel = new QWidget();
    resultsLayout = new QVBoxLayout(resultsPanel);
    resultsLayout->setContentsMargins(2, 2, 2, 2);
    resultsLabel = new QLabel("Search Results", this);
    resultsDisplay = new QTextEdit(this);
    resultsDisplay->setReadOnly(true);
    resultsDisplay->setPlaceholderText("Search results will appear here...");
    resultsDisplay->setLineWrapMode(QTextEdit::WidgetWidth);
    resultsDisplay->setMinimumHeight(150);
    resultsLayout->addWidget(resultsLabel);
    resultsLayout->addWidget(resultsDisplay);
    
    // Right: Summary
    summaryPanel = new QWidget();
    summaryLayout = new QVBoxLayout(summaryPanel);
    summaryLayout->setContentsMargins(2, 2, 2, 2);
    summaryLabel = new QLabel("Summary", this);
    summaryDisplay = new QTextEdit(this);
    summaryDisplay->setReadOnly(true);
    summaryDisplay->setPlaceholderText("Document summary will appear here...");
    summaryDisplay->setLineWrapMode(QTextEdit::WidgetWidth);
    summaryDisplay->setMinimumHeight(150);
    summaryLayout->addWidget(summaryLabel);
    summaryLayout->addWidget(summaryDisplay);
    
    middleSplitter->addWidget(resultsPanel);
    middleSplitter->addWidget(summaryPanel);
    middleSplitter->setSizes({400, 400});
    middleSplitter->setCollapsible(0, false);
    middleSplitter->setCollapsible(1, false);
    
    mainLayout->addWidget(middleSplitter);
    
    // Bottom section - Keywords, Questions, Graph (using splitter for resizability)
    QSplitter* bottomSplitter = new QSplitter(Qt::Horizontal, this);
    
    // Keywords Panel
    keywordsPanel = new QWidget();
    keywordsLayout = new QVBoxLayout(keywordsPanel);
    keywordsLayout->setContentsMargins(2, 2, 2, 2);
    keywordsLabel = new QLabel("Keywords", this);
    keywordsList = new QListWidget(this);
    keywordsList->setMinimumWidth(150);
    keywordsLayout->addWidget(keywordsLabel);
    keywordsLayout->addWidget(keywordsList);
    bottomSplitter->addWidget(keywordsPanel);
    
    // Questions Panel - Use QTextEdit for better text display
    questionsPanel = new QWidget();
    questionsLayout = new QVBoxLayout(questionsPanel);
    questionsLayout->setContentsMargins(2, 2, 2, 2);
    questionsLabel = new QLabel("Generated Questions", this);
    questionsList = new QTextEdit(this);
    questionsList->setReadOnly(true);
    questionsList->setPlaceholderText("Generated questions will appear here...");
    questionsList->setLineWrapMode(QTextEdit::WidgetWidth);
    questionsList->setMinimumWidth(300);
    questionsLayout->addWidget(questionsLabel);
    questionsLayout->addWidget(questionsList);
    bottomSplitter->addWidget(questionsPanel);
    
    // Graph Panel
    graphPanel = new QWidget();
    graphLayout = new QVBoxLayout(graphPanel);
    graphLayout->setContentsMargins(2, 2, 2, 2);
    graphLabel = new QLabel("Topic Graph", this);
    graphDisplay = new QTextEdit(this);
    graphDisplay->setReadOnly(true);
    graphDisplay->setPlaceholderText("Topic relationship graph will appear here...");
    graphDisplay->setLineWrapMode(QTextEdit::WidgetWidth);
    graphDisplay->setMinimumWidth(250);
    graphLayout->addWidget(graphLabel);
    graphLayout->addWidget(graphDisplay);
    bottomSplitter->addWidget(graphPanel);
    
    bottomSplitter->setCollapsible(0, false);
    bottomSplitter->setCollapsible(1, false);
    bottomSplitter->setCollapsible(2, false);
    
    mainLayout->addWidget(bottomSplitter);
    
    // Set window properties
    setWindowTitle("DSA-Powered Document Search & Learning Assistant");
    resize(1400, 900);
    setMinimumSize(1000, 700);
}

void MainWindow::setupMenus() {
    QMenuBar* menuBar = this->menuBar();
    
    // File menu
    fileMenu = menuBar->addMenu("File");
    QAction* loadAction = new QAction("Load Documents...", this);
    loadAction->setShortcut(QKeySequence::Open);
    connect(loadAction, &QAction::triggered, this, &MainWindow::onLoadFiles);
    fileMenu->addAction(loadAction);
    
    // Search menu
    searchMenu = menuBar->addMenu("Search");
    QAction* searchAction = new QAction("Execute Search", this);
    searchAction->setShortcut(QKeySequence::Find);
    connect(searchAction, &QAction::triggered, this, &MainWindow::onSearch);
    searchMenu->addAction(searchAction);
    
    // Analyze menu
    analyzeMenu = menuBar->addMenu("Analyze");
    QAction* summaryAction = new QAction("Generate Summary", this);
    connect(summaryAction, &QAction::triggered, this, &MainWindow::onGenerateSummary);
    analyzeMenu->addAction(summaryAction);
    
    QAction* keywordsAction = new QAction("Extract Keywords", this);
    connect(keywordsAction, &QAction::triggered, this, &MainWindow::onExtractKeywords);
    analyzeMenu->addAction(keywordsAction);
    
    QAction* questionsAction = new QAction("Generate Questions", this);
    connect(questionsAction, &QAction::triggered, this, &MainWindow::onGenerateQuestions);
    analyzeMenu->addAction(questionsAction);
    
    QAction* graphAction = new QAction("Show Topic Graph", this);
    connect(graphAction, &QAction::triggered, this, &MainWindow::onShowGraph);
    analyzeMenu->addAction(graphAction);
    
    // Help menu
    helpMenu = menuBar->addMenu("Help");
    QAction* aboutAction = new QAction("About", this);
    connect(aboutAction, &QAction::triggered, this, &MainWindow::onAbout);
    helpMenu->addAction(aboutAction);
}

void MainWindow::onLoadFiles() {
    QStringList fileNames = QFileDialog::getOpenFileNames(
        this,
        "Select Documents",
        "",
        "Text Files (*.txt);;PDF Files (*.pdf);;All Files (*)"
    );
    
    if (fileNames.isEmpty()) {
        return;
    }
    
    int loadedCount = 0;
    int failedCount = 0;
    QStringList failedFiles;
    
    for (const QString& fileName : fileNames) {
        std::string filePath = fileName.toStdString();
        int docId = static_cast<int>(searchEngine.getDocumentCount());
        
        Document doc = processor.loadFile(filePath, docId);
        if (doc.id != -1 && !doc.content.empty() && doc.content.length() >= 100) {
            searchEngine.addDocument(doc);
            // Add to document selector
            QFileInfo fileInfo(fileName);
            docSelectorCombo->addItem(QString("%1 - %2").arg(docId).arg(fileInfo.fileName()), docId);
            loadedCount++;
        } else {
            failedCount++;
            QFileInfo fileInfo(fileName);
            failedFiles.append(fileInfo.fileName());
            
            // If PDF, provide more specific error
            if (fileInfo.suffix().toLower() == "pdf") {
                // Check if pdftotext is available
                QProcess checkProcess;
                checkProcess.start("which", QStringList() << "pdftotext");
                checkProcess.waitForFinished(1000);
                if (checkProcess.exitCode() != 0) {
                    // pdftotext not installed - this is likely the problem
                    QMessageBox::critical(this, "PDF Extraction Failed",
                        QString("Failed to extract readable text from PDF: %1\n\n")
                        .arg(fileInfo.fileName()) +
                        "Please install 'pdftotext' for proper PDF text extraction:\n\n" +
                        "  macOS: brew install poppler\n" +
                        "  Linux: sudo apt-get install poppler-utils\n\n" +
                        "The built-in textutil may extract PDF structure instead of text.");
                }
            }
        }
    }
    
    if (loadedCount > 0) {
        updateStatus(QString("Loaded %1 document(s)").arg(loadedCount));
        // Auto-select first document and analyze it
        if (docSelectorCombo->count() > 0) {
            docSelectorCombo->setCurrentIndex(0);
            onDocumentSelected();
            onAnalyzeDocument();
        }
        
        QString message = QString("Successfully loaded %1 document(s).").arg(loadedCount);
        if (failedCount > 0) {
            message += QString("\n\nFailed to load %1 file(s):\n%2")
                       .arg(failedCount)
                       .arg(failedFiles.join(", "));
            QFileInfo firstFile(fileNames.first());
            if (firstFile.suffix().toLower() == "pdf") {
                message += "\n\nNote: For best PDF extraction, install 'pdftotext':\n";
                message += "  macOS: brew install poppler\n";
                message += "  Linux: sudo apt-get install poppler-utils\n";
                message += "\nWithout pdftotext, extraction may include PDF metadata.";
            }
            QMessageBox::warning(this, "Files Loaded (Partial)", message);
        } else {
            QMessageBox::information(this, "Files Loaded", message);
        }
    } else {
        QString errorMsg = "Failed to load any documents.";
        if (fileNames.first().endsWith(".pdf", Qt::CaseInsensitive)) {
            errorMsg += "\n\nPDF support requires 'pdftotext' command.\n";
            errorMsg += "Install it with: brew install poppler (macOS) or apt-get install poppler-utils (Linux)";
        }
        QMessageBox::warning(this, "Load Failed", errorMsg);
    }
}

void MainWindow::onSearchTextChanged() {
    // Stop the previous timer if it's running
    searchTimer->stop();
    
    // Only auto-search if there's text and documents are loaded
    QString queryText = searchInput->text().trimmed();
    if (!queryText.isEmpty() && searchEngine.getDocumentCount() > 0) {
        // Start timer - will trigger search after user stops typing for 500ms
        searchTimer->start();
    } else if (queryText.isEmpty()) {
        // Clear results if search field is empty
        resultsDisplay->clear();
        resultsDisplay->setPlaceholderText("Search results will appear here...");
    }
}

void MainWindow::onSearch() {
    QString queryText = searchInput->text().trimmed();
    
    // Clear results if query is empty
    if (queryText.isEmpty()) {
        resultsDisplay->clear();
        resultsDisplay->setPlaceholderText("Search results will appear here...");
        updateStatus("Ready. Enter a search query.");
        return;
    }
    
    // Check if documents are loaded
    if (searchEngine.getDocumentCount() == 0) {
        resultsDisplay->clear();
        resultsDisplay->setPlainText("No documents loaded. Please load documents first using the 'Load Files...' button.");
        updateStatus("No documents loaded.");
        return;
    }
    
    // Perform search
    std::string query = queryText.toStdString();
    std::vector<QueryResult> results = searchEngine.search(query);
    
    // Display results
    resultsDisplay->clear();
    if (results.empty()) {
        QString noResultsMsg = "No results found for: \"" + queryText + "\"\n\n";
        
        // Check if documents have content
        bool hasContent = false;
        for (size_t i = 0; i < searchEngine.getDocumentCount(); ++i) {
            const Document& doc = searchEngine.getDocument(static_cast<int>(i));
            if (!doc.content.empty() && doc.content.length() > 50) {
                hasContent = true;
                break;
            }
        }
        
        if (!hasContent) {
            noResultsMsg += "WARNING: Documents appear to be empty or not properly loaded.\n";
            noResultsMsg += "Please reload your documents.\n\n";
        }
        
        noResultsMsg += "Suggestions:\n";
        noResultsMsg += "- Try different keywords\n";
        noResultsMsg += "- Use specific terms from the document\n";
        noResultsMsg += "- Check spelling\n";
        noResultsMsg += "- Try partial words (prefix matching)\n";
        noResultsMsg += "- Search is case-insensitive\n\n";
        noResultsMsg += QString("Total documents loaded: %1\n").arg(searchEngine.getDocumentCount());
        
        // Show sample content from first document if available
        if (searchEngine.getDocumentCount() > 0) {
            const Document& firstDoc = searchEngine.getDocument(0);
            if (!firstDoc.content.empty()) {
                QString content = QString::fromStdString(firstDoc.content);
                QString preview = content.left(200);
                noResultsMsg += "\nFirst document preview (first 200 chars):\n";
                noResultsMsg += preview + "...";
            }
        }
        
        resultsDisplay->setPlainText(noResultsMsg);
    } else {
        std::ostringstream oss;
        oss << "Found " << results.size() << " result(s) for: \"" << query << "\"\n\n";
        
        for (size_t i = 0; i < results.size(); ++i) {
            const auto& result = results[i];
            oss << "Result " << (i + 1) << ":\n";
            oss << "File: " << result.filename << "\n";
            oss << "Score: " << std::fixed << std::setprecision(4) << result.score << "\n";
            oss << "Snippet: " << result.snippet << "\n\n";
            
            currentDocId = result.docId; // Store for later analysis
        }
        
        resultsDisplay->setPlainText(QString::fromStdString(oss.str()));
    }
    
    updateStatus(QString("Search completed: %1 result(s)").arg(results.size()));
}

void MainWindow::onDocumentSelected() {
    int index = docSelectorCombo->currentIndex();
    if (index >= 0) {
        int docId = docSelectorCombo->itemData(index).toInt();
        currentDocId = docId;
    }
}

void MainWindow::onAnalyzeDocument() {
    if (currentDocId == -1 || searchEngine.getDocumentCount() == 0) {
        // Try to get from combo box
        int index = docSelectorCombo->currentIndex();
        if (index >= 0) {
            currentDocId = docSelectorCombo->itemData(index).toInt();
        } else {
            QMessageBox::information(this, "Analyze", "Please load and select a document first.");
            return;
        }
    }
    
    const Document& doc = searchEngine.getDocument(currentDocId);
    if (doc.id == -1) {
        QMessageBox::warning(this, "Analyze", "Invalid document selected.");
        return;
    }
    
    // Generate all analyses at once
    // Summary
    std::string summary = summarizer.summarize(doc, 5);
    summaryDisplay->setPlainText(QString::fromStdString(summary));
    
    // Keywords
    std::vector<std::string> keywords = extractor.extract(doc, 15);
    keywordsList->clear();
    for (const auto& keyword : keywords) {
        keywordsList->addItem(QString::fromStdString(keyword));
    }
    
    // Questions
    std::vector<Question> questions = questionGen.generate(doc, "all", 3);
    questionsList->clear();
    QString questionsText;
    for (size_t i = 0; i < questions.size(); ++i) {
        const auto& q = questions[i];
        questionsText += QString("Question %1:\n").arg(i + 1);
        questionsText += QString("[%1] %2\n").arg(QString::fromStdString(q.type), 
                                                   QString::fromStdString(q.question));
        if (q.type == "mcq" && !q.options.empty()) {
            questionsText += "  Options: ";
            for (size_t j = 0; j < q.options.size(); ++j) {
                questionsText += QString::fromStdString(q.options[j]);
                if (j < q.options.size() - 1) {
                    questionsText += ", ";
                }
            }
            questionsText += "\n";
        }
        questionsText += QString("  Answer: %1\n\n").arg(QString::fromStdString(q.answer));
    }
    questionsList->setPlainText(questionsText);
    
    updateStatus(QString("Analyzed document: %1").arg(QString::fromStdString(doc.filename)));
}

void MainWindow::onGenerateSummary() {
    if (currentDocId == -1 || searchEngine.getDocumentCount() == 0) {
        // Try to get from combo box
        int index = docSelectorCombo->currentIndex();
        if (index >= 0) {
            currentDocId = docSelectorCombo->itemData(index).toInt();
        } else {
            QMessageBox::information(this, "Summary", "Please load and select a document first.");
            return;
        }
    }
    
    const Document& doc = searchEngine.getDocument(currentDocId);
    if (doc.id == -1) {
        QMessageBox::warning(this, "Summary", "Invalid document selected.");
        return;
    }
    
    std::string summary = summarizer.summarize(doc, 5);
    summaryDisplay->setPlainText(QString::fromStdString(summary));
    
    updateStatus("Summary generated.");
}

void MainWindow::onExtractKeywords() {
    if (currentDocId == -1 || searchEngine.getDocumentCount() == 0) {
        // Try to get from combo box
        int index = docSelectorCombo->currentIndex();
        if (index >= 0) {
            currentDocId = docSelectorCombo->itemData(index).toInt();
        } else {
            QMessageBox::information(this, "Keywords", "Please load and select a document first.");
            return;
        }
    }
    
    const Document& doc = searchEngine.getDocument(currentDocId);
    if (doc.id == -1) {
        QMessageBox::warning(this, "Keywords", "Invalid document selected.");
        return;
    }
    
    std::vector<std::string> keywords = extractor.extract(doc, 15);
    
    keywordsList->clear();
    for (const auto& keyword : keywords) {
        keywordsList->addItem(QString::fromStdString(keyword));
    }
    
    updateStatus(QString("Extracted %1 keywords").arg(keywords.size()));
}

void MainWindow::onGenerateQuestions() {
    if (currentDocId == -1 || searchEngine.getDocumentCount() == 0) {
        // Try to get from combo box
        int index = docSelectorCombo->currentIndex();
        if (index >= 0) {
            currentDocId = docSelectorCombo->itemData(index).toInt();
        } else {
            QMessageBox::information(this, "Questions", "Please load and select a document first.");
            return;
        }
    }
    
    const Document& doc = searchEngine.getDocument(currentDocId);
    if (doc.id == -1) {
        QMessageBox::warning(this, "Questions", "Invalid document selected.");
        return;
    }
    
    std::vector<Question> questions = questionGen.generate(doc, "all", 3);
    
    questionsList->clear();
    QString questionsText;
    for (size_t i = 0; i < questions.size(); ++i) {
        const auto& q = questions[i];
        questionsText += QString("Question %1:\n").arg(i + 1);
        questionsText += QString("[%1] %2\n").arg(QString::fromStdString(q.type), 
                                                   QString::fromStdString(q.question));
        if (q.type == "mcq" && !q.options.empty()) {
            questionsText += "  Options: ";
            for (size_t j = 0; j < q.options.size(); ++j) {
                questionsText += QString::fromStdString(q.options[j]);
                if (j < q.options.size() - 1) {
                    questionsText += ", ";
                }
            }
            questionsText += "\n";
        }
        questionsText += QString("  Answer: %1\n\n").arg(QString::fromStdString(q.answer));
    }
    questionsList->setPlainText(questionsText);
    
    updateStatus(QString("Generated %1 questions").arg(questions.size()));
}

void MainWindow::onShowGraph() {
    if (searchEngine.getDocumentCount() == 0) {
        QMessageBox::information(this, "Graph", "Please load documents first.");
        return;
    }
    
    // Extract keywords from all documents
    std::unordered_set<std::string> allKeywordsSet;
    for (size_t i = 0; i < searchEngine.getDocumentCount(); ++i) {
        const Document& doc = searchEngine.getDocument(static_cast<int>(i));
        std::vector<std::string> keywords = extractor.extract(doc, 10);
        allKeywordsSet.insert(keywords.begin(), keywords.end());
    }
    
    std::vector<std::string> allKeywords(allKeywordsSet.begin(), allKeywordsSet.end());
    
    // Get all documents
    std::vector<Document> allDocs;
    for (size_t i = 0; i < searchEngine.getDocumentCount(); ++i) {
        allDocs.push_back(searchEngine.getDocument(static_cast<int>(i)));
    }
    
    // Build graph
    topicGraph.build(allDocs, allKeywords);
    
    // Display visualization
    std::string visualization = topicGraph.visualize();
    graphDisplay->setPlainText(QString::fromStdString(visualization));
    
    updateStatus("Topic graph generated.");
}

void MainWindow::onAbout() {
    QMessageBox::about(this, "About",
                      "DSA-Powered Document Search & Learning Assistant\n\n"
                      "Version 1.0.0\n\n"
                      "A C++/Qt application demonstrating Data Structures and Algorithms:\n"
                      "- Trie for prefix search\n"
                      "- Inverted Index for document retrieval\n"
                      "- TF-IDF for relevance ranking\n"
                      "- TextRank for summarization\n"
                      "- Min-heap for keyword extraction\n"
                      "- Graph algorithms for topic relations\n\n"
                      "No AI/ML APIs used - Pure DSA implementation.");
}

void MainWindow::updateStatus(const QString& message) {
    statusBar()->showMessage(message, 5000);
}

