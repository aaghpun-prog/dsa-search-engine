#include "gui/MainWindow.h"
#include <QApplication>
#include <QStyleFactory>

/**
 * @brief Main entry point for DSA Educational Search Assistant
 */
int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    // Set application properties
    app.setApplicationName("DSA Educational Search Assistant");
    app.setApplicationVersion("1.0.0");
    app.setOrganizationName("DSA Project");
    
    // Create and show main window
    MainWindow window;
    window.show();
    
    return app.exec();
}

