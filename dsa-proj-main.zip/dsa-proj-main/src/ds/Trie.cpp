#include "Trie.h"
#include <algorithm>

Trie::Trie() {
    root = new Node();
}

Trie::~Trie() {
    delete root;
}

void Trie::insert(const std::string& word) {
    Node* current = root;
    for (char c : word) {
        if (current->children.find(c) == current->children.end()) {
            current->children[c] = new Node();
        }
        current = current->children[c];
    }
    current->isEnd = true;
}

bool Trie::search(const std::string& word) const {
    Node* current = root;
    for (char c : word) {
        if (current->children.find(c) == current->children.end()) {
            return false;
        }
        current = current->children[c];
    }
    return current->isEnd;
}

void Trie::collectWords(Node* node, const std::string& prefix, std::vector<std::string>& results) const {
    if (node->isEnd) {
        results.push_back(prefix);
    }
    
    for (const auto& pair : node->children) {
        collectWords(pair.second, prefix + pair.first, results);
    }
}

std::vector<std::string> Trie::prefixMatch(const std::string& prefix) const {
    std::vector<std::string> results;
    Node* current = root;
    
    // Navigate to prefix node
    for (char c : prefix) {
        if (current->children.find(c) == current->children.end()) {
            return results; // No words with this prefix
        }
        current = current->children[c];
    }
    
    // Collect all words starting with this prefix
    collectWords(current, prefix, results);
    return results;
}

