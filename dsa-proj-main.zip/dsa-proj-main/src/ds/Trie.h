#ifndef TRIE_H
#define TRIE_H

#include <string>
#include <vector>
#include <unordered_map>

/**
 * @brief Trie data structure for efficient prefix search
 * 
 * Used for autocomplete and prefix matching in search queries.
 */
class Trie {
private:
    /**
     * @brief Trie node structure
     */
    struct Node {
        std::unordered_map<char, Node*> children; // Child nodes by character
        bool isEnd;                                 // True if node marks end of word

        Node() : isEnd(false) {}
        
        ~Node() {
            for (auto& pair : children) {
                delete pair.second;
            }
        }
    };

    Node* root; // Root node of the trie

    /**
     * @brief Recursively collect all words with given prefix
     * @param node Current node
     * @param prefix Current prefix string
     * @param results Output vector to store results
     */
    void collectWords(Node* node, const std::string& prefix, std::vector<std::string>& results) const;

public:
    Trie();
    ~Trie();

    /**
     * @brief Insert a word into the trie
     * @param word Word to insert
     */
    void insert(const std::string& word);

    /**
     * @brief Search for exact word match
     * @param word Word to search
     * @return True if word exists in trie
     */
    bool search(const std::string& word) const;

    /**
     * @brief Find all words with given prefix
     * @param prefix Prefix to search for
     * @return Vector of words matching the prefix
     */
    std::vector<std::string> prefixMatch(const std::string& prefix) const;
};

#endif // TRIE_H

