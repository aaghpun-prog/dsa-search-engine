#include "TextRank.h"
#include <cmath>
#include <algorithm>
#include <sstream>
#include <cctype>

double TextRank::cosineSimilarity(const std::unordered_map<std::string, int>& vec1,
                                   const std::unordered_map<std::string, int>& vec2) const {
    double dotProduct = 0.0;
    double norm1 = 0.0;
    double norm2 = 0.0;

    // Compute dot product and norms
    for (const auto& pair : vec1) {
        norm1 += pair.second * pair.second;
        if (vec2.find(pair.first) != vec2.end()) {
            dotProduct += pair.second * vec2.at(pair.first);
        }
    }

    for (const auto& pair : vec2) {
        norm2 += pair.second * pair.second;
    }

    if (norm1 == 0.0 || norm2 == 0.0) {
        return 0.0;
    }

    return dotProduct / (sqrt(norm1) * sqrt(norm2));
}

std::vector<std::string> TextRank::tokenize(const std::string& sentence) const {
    std::vector<std::string> tokens;
    std::stringstream ss(sentence);
    std::string word;
    
    while (ss >> word) {
        // Convert to lowercase and remove punctuation
        std::string cleaned;
        for (char c : word) {
            if (std::isalnum(c)) {
                cleaned += std::tolower(c);
            }
        }
        if (!cleaned.empty()) {
            tokens.push_back(cleaned);
        }
    }
    
    return tokens;
}

std::unordered_map<std::string, int> TextRank::buildWordVector(const std::string& sentence) const {
    std::unordered_map<std::string, int> wordVec;
    std::vector<std::string> tokens = tokenize(sentence);
    
    for (const auto& token : tokens) {
        wordVec[token]++;
    }
    
    return wordVec;
}

std::vector<std::pair<int, double>> TextRank::compute(const std::vector<std::string>& sentences) const {
    if (sentences.empty()) {
        return std::vector<std::pair<int, double>>();
    }

    int n = static_cast<int>(sentences.size());
    
    // Build word vectors for each sentence
    std::vector<std::unordered_map<std::string, int>> wordVectors;
    for (const auto& sentence : sentences) {
        wordVectors.push_back(buildWordVector(sentence));
    }

    // Build similarity matrix (adjacency matrix representation)
    std::vector<std::vector<double>> similarity(n, std::vector<double>(n, 0.0));
    
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (i != j) {
                double sim = cosineSimilarity(wordVectors[i], wordVectors[j]);
                if (sim > SIMILARITY_THRESHOLD) {
                    similarity[i][j] = sim;
                }
            }
        }
    }

    // Compute out-degrees (for normalization)
    std::vector<double> outDegree(n, 0.0);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            outDegree[i] += similarity[i][j];
        }
        if (outDegree[i] == 0.0) {
            outDegree[i] = 1.0; // Avoid division by zero
        }
    }

    // Initialize scores
    std::vector<double> scores(n, 1.0 / n);
    std::vector<double> newScores(n);

    // Iterative PageRank computation
    for (int iter = 0; iter < MAX_ITERATIONS; ++iter) {
        for (int i = 0; i < n; ++i) {
            double sum = 0.0;
            for (int j = 0; j < n; ++j) {
                if (similarity[j][i] > 0.0) {
                    sum += scores[j] * similarity[j][i] / outDegree[j];
                }
            }
            newScores[i] = (1.0 - DAMPING_FACTOR) + DAMPING_FACTOR * sum;
        }

        // Check convergence
        double diff = 0.0;
        for (int i = 0; i < n; ++i) {
            diff += std::abs(newScores[i] - scores[i]);
        }
        
        scores = newScores;
        if (diff < 1e-6) {
            break; // Converged
        }
    }

    // Create result pairs
    std::vector<std::pair<int, double>> result;
    for (int i = 0; i < n; ++i) {
        result.push_back({i, scores[i]});
    }

    // Sort by score descending
    std::sort(result.begin(), result.end(),
              [](const std::pair<int, double>& a, const std::pair<int, double>& b) {
                  return a.second > b.second;
              });

    return result;
}

