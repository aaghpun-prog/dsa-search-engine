#ifndef TEXTRANK_H
#define TEXTRANK_H

#include <string>
#include <vector>
#include <unordered_map>
#include <utility>

/**
 * @brief TextRank algorithm for extractive summarization
 * 
 * Implements a graph-based ranking algorithm (similar to PageRank)
 * to score and extract important sentences from text.
 */
class TextRank {
private:
    static constexpr double DAMPING_FACTOR = 0.85;  // PageRank damping factor
    static constexpr double SIMILARITY_THRESHOLD = 0.1; // Minimum similarity for edge
    static constexpr int MAX_ITERATIONS = 50;       // Maximum iterations for convergence

    /**
     * @brief Compute cosine similarity between two sentence vectors
     * @param vec1 First sentence vector (word frequencies)
     * @param vec2 Second sentence vector (word frequencies)
     * @return Cosine similarity score [0, 1]
     */
    double cosineSimilarity(const std::unordered_map<std::string, int>& vec1,
                           const std::unordered_map<std::string, int>& vec2) const;

    /**
     * @brief Build word frequency vector for a sentence
     * @param sentence Sentence to process
     * @return Map of word -> frequency
     */
    std::unordered_map<std::string, int> buildWordVector(const std::string& sentence) const;

    /**
     * @brief Tokenize sentence into words
     * @param sentence Input sentence
     * @return Vector of lowercase words
     */
    std::vector<std::string> tokenize(const std::string& sentence) const;

public:
    TextRank() = default;
    ~TextRank() = default;

    /**
     * @brief Compute TextRank scores for sentences
     * @param sentences Vector of sentences to rank
     * @return Vector of (sentence index, score) pairs, sorted by score (descending)
     */
    std::vector<std::pair<int, double>> compute(const std::vector<std::string>& sentences) const;
};

#endif // TEXTRANK_H

