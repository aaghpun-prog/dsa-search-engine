#ifndef INVERTED_INDEX_H
#define INVERTED_INDEX_H

#include <string>
#include <vector>
#include <unordered_map>
#include <utility>

/**
 * @brief Inverted Index data structure for fast text search
 * 
 * Maps terms to lists of (document ID, position) pairs.
 * Essential for efficient document retrieval.
 */
class InvertedIndex {
private:
    // Map: term -> vector of (docId, position) pairs
    std::unordered_map<std::string, std::vector<std::pair<int, int>>> index;

public:
    InvertedIndex() = default;
    ~InvertedIndex() = default;

    /**
     * @brief Add a term occurrence to the index
     * @param term Term to index
     * @param docId Document ID where term appears
     * @param position Position in document (token index)
     */
    void addTerm(const std::string& term, int docId, int position);

    /**
     * @brief Search for a term in the index
     * @param term Term to search for
     * @return Vector of (docId, position) pairs where term appears
     */
    std::vector<std::pair<int, int>> find(const std::string& term) const;

    /**
     * @brief Get all documents containing a term
     * @param term Term to search for
     * @return Set of document IDs containing the term
     */
    std::vector<int> getDocuments(const std::string& term) const;

    /**
     * @brief Check if term exists in index
     * @param term Term to check
     * @return True if term exists
     */
    bool contains(const std::string& term) const;

    /**
     * @brief Clear the entire index
     */
    void clear();
};

#endif // INVERTED_INDEX_H

