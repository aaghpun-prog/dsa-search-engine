#ifndef TFIDF_H
#define TFIDF_H

#include <string>
#include <vector>
#include <unordered_map>
#include "../../include/types.h"
#include "InvertedIndex.h"

/**
 * @brief TF-IDF (Term Frequency-Inverse Document Frequency) ranking algorithm
 * 
 * Computes relevance scores for documents based on term frequency and
 * inverse document frequency to rank search results.
 */
class TFIDF {
private:
    std::vector<Document> documents;
    InvertedIndex* index;
    int totalDocs;

    /**
     * @brief Compute term frequency for a term in a document
     * @param term Term to compute TF for
     * @param docId Document ID
     * @return Term frequency (normalized)
     */
    double computeTF(const std::string& term, int docId) const;

    /**
     * @brief Compute inverse document frequency for a term
     * @param term Term to compute IDF for
     * @return Inverse document frequency
     */
    double computeIDF(const std::string& term) const;

public:
    TFIDF(const std::vector<Document>& docs, InvertedIndex* idx);

    /**
     * @brief Compute TF-IDF score for a term in a document
     * @param term Term
     * @param docId Document ID
     * @return TF-IDF score
     */
    double computeScore(const std::string& term, int docId) const;

    /**
     * @brief Rank documents by relevance to query terms
     * @param queryTerms Vector of query terms
     * @param candidateDocs Vector of candidate document IDs
     * @return Vector of (docId, score) pairs, sorted by score (descending)
     */
    std::vector<std::pair<int, double>> rank(const std::vector<std::string>& queryTerms,
                                             const std::vector<int>& candidateDocs) const;

    /**
     * @brief Get TF-IDF score for a query against a document
     * @param queryTerms Query terms
     * @param docId Document ID
     * @return Total TF-IDF score
     */
    double getDocumentScore(const std::vector<std::string>& queryTerms, int docId) const;
};

#endif // TFIDF_H

