#include "InvertedIndex.h"
#include <algorithm>
#include <unordered_set>

void InvertedIndex::addTerm(const std::string& term, int docId, int position) {
    index[term].push_back({docId, position});
}

std::vector<std::pair<int, int>> InvertedIndex::find(const std::string& term) const {
    auto it = index.find(term);
    if (it != index.end()) {
        return it->second;
    }
    return std::vector<std::pair<int, int>>();
}

std::vector<int> InvertedIndex::getDocuments(const std::string& term) const {
    auto it = index.find(term);
    if (it == index.end()) {
        return std::vector<int>();
    }

    std::unordered_set<int> docSet;
    for (const auto& pair : it->second) {
        docSet.insert(pair.first);
    }

    std::vector<int> docs(docSet.begin(), docSet.end());
    return docs;
}

bool InvertedIndex::contains(const std::string& term) const {
    return index.find(term) != index.end();
}

void InvertedIndex::clear() {
    index.clear();
}

