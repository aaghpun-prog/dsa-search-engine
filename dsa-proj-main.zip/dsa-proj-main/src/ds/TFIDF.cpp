#include "TFIDF.h"
#include <cmath>
#include <algorithm>

TFIDF::TFIDF(const std::vector<Document>& docs, InvertedIndex* idx)
    : documents(docs), index(idx), totalDocs(static_cast<int>(docs.size())) {
}

double TFIDF::computeTF(const std::string& term, int docId) const {
    if (docId < 0 || docId >= static_cast<int>(documents.size())) {
        return 0.0;
    }

    const auto& doc = documents[docId];
    auto it = doc.termFreq.find(term);
    if (it == doc.termFreq.end()) {
        return 0.0;
    }

    // Normalized TF: term count / total terms in document
    int totalTerms = static_cast<int>(doc.tokens.size());
    if (totalTerms == 0) return 0.0;
    
    return static_cast<double>(it->second) / totalTerms;
}

double TFIDF::computeIDF(const std::string& term) const {
    if (totalDocs == 0) return 0.0;

    std::vector<int> docsWithTerm = index->getDocuments(term);
    int docsContaining = static_cast<int>(docsWithTerm.size());
    
    if (docsContaining == 0) return 0.0;
    
    // IDF = log(totalDocs / docsContaining)
    return log(static_cast<double>(totalDocs) / docsContaining);
}

double TFIDF::computeScore(const std::string& term, int docId) const {
    double tf = computeTF(term, docId);
    double idf = computeIDF(term);
    return tf * idf;
}

double TFIDF::getDocumentScore(const std::vector<std::string>& queryTerms, int docId) const {
    double totalScore = 0.0;
    for (const auto& term : queryTerms) {
        totalScore += computeScore(term, docId);
    }
    return totalScore;
}

std::vector<std::pair<int, double>> TFIDF::rank(const std::vector<std::string>& queryTerms,
                                                  const std::vector<int>& candidateDocs) const {
    std::vector<std::pair<int, double>> scoredDocs;
    
    for (int docId : candidateDocs) {
        double score = getDocumentScore(queryTerms, docId);
        if (score > 0.0) {
            scoredDocs.push_back({docId, score});
        }
    }
    
    // Sort by score descending
    std::sort(scoredDocs.begin(), scoredDocs.end(),
              [](const std::pair<int, double>& a, const std::pair<int, double>& b) {
                  return a.second > b.second;
              });
    
    return scoredDocs;
}

