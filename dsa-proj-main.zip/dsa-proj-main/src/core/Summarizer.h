#ifndef SUMMARIZER_H
#define SUMMARIZER_H

#include "../../include/types.h"
#include "../ds/TextRank.h"
#include <string>
#include <vector>

/**
 * @brief Extractive summarization using TextRank algorithm
 * 
 * Generates summaries by extracting top-ranked sentences from documents.
 */
class Summarizer {
private:
    TextRank textRank;

public:
    Summarizer() = default;
    ~Summarizer() = default;

    /**
     * @brief Generate summary for a document
     * @param doc Document to summarize
     * @param numSentences Number of top sentences to extract (default: 3)
     * @return Summary string
     */
    std::string summarize(const Document& doc, int numSentences = 3);

    /**
     * @brief Generate summary from sentences directly
     * @param sentences Vector of sentences
     * @param numSentences Number of top sentences to extract (default: 3)
     * @return Summary string
     */
    std::string summarize(const std::vector<std::string>& sentences, int numSentences = 3);
};

#endif // SUMMARIZER_H

