#ifndef TOPIC_GRAPH_H
#define TOPIC_GRAPH_H

#include "../../include/types.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

/**
 * @brief Topic relation graph using adjacency list representation
 * 
 * Builds a graph where nodes are keywords/topics and edges represent
 * co-occurrence relationships in documents.
 */
class TopicGraph {
private:
    // Adjacency list: topic -> connected topics
    std::unordered_map<std::string, std::vector<std::string>> graph;
    
    /**
     * @brief Check if two topics co-occur in the same document
     * @param topic1 First topic
     * @param topic2 Second topic
     * @param documents All documents
     * @return True if they co-occur
     */
    bool coOccur(const std::string& topic1, const std::string& topic2,
                 const std::vector<Document>& documents) const;

public:
    TopicGraph() = default;
    ~TopicGraph() = default;

    /**
     * @brief Build graph from documents based on keyword co-occurrence
     * @param documents Vector of documents
     * @param keywords Vector of keywords to use as nodes
     */
    void build(const std::vector<Document>& documents, const std::vector<std::string>& keywords);

    /**
     * @brief Get neighbors of a topic
     * @param topic Topic name
     * @return Vector of connected topics
     */
    std::vector<std::string> getNeighbors(const std::string& topic) const;

    /**
     * @brief Get all topics in the graph
     * @return Vector of all topic names
     */
    std::vector<std::string> getTopics() const;

    /**
     * @brief Generate text-based visualization of the graph
     * @return String representation of the graph (tree format)
     */
    std::string visualize() const;

    /**
     * @brief Clear the graph
     */
    void clear();
};

#endif // TOPIC_GRAPH_H

