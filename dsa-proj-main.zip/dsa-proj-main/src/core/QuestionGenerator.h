#ifndef QUESTION_GENERATOR_H
#define QUESTION_GENERATOR_H

#include "../../include/types.h"
#include "KeywordExtractor.h"
#include <string>
#include <vector>

/**
 * @brief Rule-based question generator (NO AI/ML)
 * 
 * Generates various types of questions using templates and keyword extraction.
 */
class QuestionGenerator {
private:
    KeywordExtractor extractor;

    /**
     * @brief Generate fill-in-the-blank questions
     * @param sentences Source sentences
     * @param keywords Keywords to use for blanks
     * @param numQuestions Number of questions to generate
     * @return Vector of Question objects
     */
    std::vector<Question> generateFillBlank(const std::vector<std::string>& sentences,
                                            const std::vector<std::string>& keywords,
                                            int numQuestions) const;

    /**
     * @brief Generate true/false questions
     * @param sentences Source sentences
     * @param numQuestions Number of questions to generate
     * @return Vector of Question objects
     */
    std::vector<Question> generateTrueFalse(const std::vector<std::string>& sentences,
                                             int numQuestions) const;

    /**
     * @brief Generate short answer questions
     * @param sentences Source sentences
     * @param numQuestions Number of questions to generate
     * @return Vector of Question objects
     */
    std::vector<Question> generateShortAnswer(const std::vector<std::string>& sentences,
                                               int numQuestions) const;

    /**
     * @brief Generate multiple choice questions
     * @param sentences Source sentences
     * @param keywords Keywords for answers
     * @param termFreq Term frequency map for distractors
     * @param numQuestions Number of questions to generate
     * @return Vector of Question objects
     */
    std::vector<Question> generateMCQ(const std::vector<std::string>& sentences,
                                      const std::vector<std::string>& keywords,
                                      const std::unordered_map<std::string, int>& termFreq,
                                      int numQuestions) const;

    /**
     * @brief Convert sentence to question form
     * @param sentence Declarative sentence
     * @return Interrogative question
     */
    std::string sentenceToQuestion(const std::string& sentence) const;

    /**
     * @brief Generate distractors for MCQ
     * @param correctAnswer Correct answer keyword
     * @param termFreq Term frequency map
     * @param numDistractors Number of distractors needed
     * @return Vector of distractor strings
     */
    std::vector<std::string> generateDistractors(const std::string& correctAnswer,
                                                  const std::unordered_map<std::string, int>& termFreq,
                                                  int numDistractors) const;

public:
    QuestionGenerator() = default;
    ~QuestionGenerator() = default;

    /**
     * @brief Generate questions of specified type from document
     * @param doc Source document
     * @param type Question type: "fill_blank", "true_false", "short_answer", "mcq", "all"
     * @param numQuestions Number of questions per type
     * @return Vector of Question objects
     */
    std::vector<Question> generate(const Document& doc, const std::string& type = "all", int numQuestions = 5);
};

#endif // QUESTION_GENERATOR_H

