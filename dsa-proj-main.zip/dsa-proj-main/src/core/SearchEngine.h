#ifndef SEARCH_ENGINE_H
#define SEARCH_ENGINE_H

#include "../../include/types.h"
#include "../ds/Trie.h"
#include "../ds/InvertedIndex.h"
#include "../ds/TFIDF.h"
#include "DocumentProcessor.h"
#include <string>
#include <vector>

/**
 * @brief Main search engine integrating Trie, InvertedIndex, and TF-IDF
 * 
 * Provides unified interface for document indexing and search with ranking.
 */
class SearchEngine {
private:
    std::vector<Document> documents;
    Trie trie;
    InvertedIndex index;
    TFIDF* tfidf;
    DocumentProcessor processor;

    /**
     * @brief Generate text snippet around match position
     * @param doc Document to extract snippet from
     * @param term Term that was matched
     * @param maxLength Maximum snippet length
     * @return Text snippet
     */
    std::string generateSnippet(const Document& doc, const std::string& term, int maxLength = 150) const;

public:
    SearchEngine();
    ~SearchEngine();

    /**
     * @brief Add a document to the search index
     * @param doc Document to index
     */
    void addDocument(const Document& doc);

    /**
     * @brief Search for query terms
     * @param query Search query string
     * @return Vector of QueryResult objects, sorted by relevance
     */
    std::vector<QueryResult> search(const std::string& query);

    /**
     * @brief Get prefix suggestions for autocomplete
     * @param prefix Prefix to complete
     * @return Vector of matching words
     */
    std::vector<std::string> getSuggestions(const std::string& prefix);

    /**
     * @brief Get document by ID
     * @param docId Document ID
     * @return Document reference, or empty Document if not found
     */
    const Document& getDocument(int docId) const;

    /**
     * @brief Get total number of indexed documents
     * @return Document count
     */
    size_t getDocumentCount() const;

    /**
     * @brief Clear all indexed documents
     */
    void clear();
};

#endif // SEARCH_ENGINE_H

