#include "SearchEngine.h"
#include <algorithm>
#include <sstream>
#include <set>
#include <cctype>
#include <cstring>

SearchEngine::SearchEngine() {
    tfidf = nullptr;
}

SearchEngine::~SearchEngine() {
    delete tfidf;
}

void SearchEngine::addDocument(const Document& doc) {
    documents.push_back(doc);
    
    // Rebuild TF-IDF with updated document collection
    delete tfidf;
    tfidf = new TFIDF(documents, &index);
    
    // Index terms in Trie and InvertedIndex
    int docId = doc.id;
    int position = 0;
    
    // If doc.tokens is empty (e.g., after PDF cleaning), try re-tokenizing content
    if (doc.tokens.empty() && !doc.content.empty()) {
        // Re-tokenize content to ensure we have something to index
        std::vector<std::string> tokens = processor.tokenize(doc.content);
        for (const auto& token : tokens) {
            if (!token.empty()) {
                // Add to trie
                trie.insert(token);
                
                // Add to inverted index
                index.addTerm(token, docId, position);
                position++;
            }
        }
    } else {
        // Use existing tokens
        for (const auto& token : doc.tokens) {
            if (!token.empty()) {
                // Add to trie
                trie.insert(token);
                
                // Add to inverted index
                index.addTerm(token, docId, position);
                position++;
            }
        }
    }
}

std::string SearchEngine::generateSnippet(const Document& doc, const std::string& term, int maxLength) const {
    // Find first occurrence of term in content
    std::string lowerContent = doc.content;
    std::string lowerTerm = term;
    
    std::transform(lowerContent.begin(), lowerContent.end(), lowerContent.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    std::transform(lowerTerm.begin(), lowerTerm.end(), lowerTerm.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    
    size_t pos = lowerContent.find(lowerTerm);
    if (pos == std::string::npos) {
        // Term not found, return beginning of document
        if (doc.content.length() > static_cast<size_t>(maxLength)) {
            return doc.content.substr(0, maxLength) + "...";
        }
        return doc.content;
    }
    
    // Extract snippet around match
    int start = std::max(0, static_cast<int>(pos) - maxLength / 2);
    int length = std::min(static_cast<int>(doc.content.length() - start), maxLength);
    
    std::string snippet = doc.content.substr(start, length);
    
    if (start > 0) snippet = "..." + snippet;
    if (start + length < static_cast<int>(doc.content.length())) snippet += "...";
    
    return snippet;
}

std::vector<QueryResult> SearchEngine::search(const std::string& query) {
    std::vector<QueryResult> results;
    
    if (documents.empty() || query.empty() || tfidf == nullptr) {
        return results;
    }
    
    // Tokenize query (don't filter stopwords for search)
    std::vector<std::string> queryTerms = processor.tokenizeQuery(query);
    if (queryTerms.empty()) {
        return results;
    }
    
    // Find candidate documents using inverted index
    // Use OR logic: a document matches if it contains ANY of the query terms
    std::set<int> candidateDocIds;
    for (const auto& term : queryTerms) {
        std::vector<int> docs = index.getDocuments(term);
        candidateDocIds.insert(docs.begin(), docs.end());
    }
    
    // If no documents found with exact matches, try prefix matching for all terms
    if (candidateDocIds.empty()) {
        for (const auto& term : queryTerms) {
            std::vector<std::string> prefixes = trie.prefixMatch(term);
            for (const auto& prefix : prefixes) {
                std::vector<int> docs = index.getDocuments(prefix);
                candidateDocIds.insert(docs.begin(), docs.end());
            }
        }
    }
    
    // If still no candidates, search in document content directly (fallback)
    // This handles cases where indexing might have failed or terms don't match
    if (candidateDocIds.empty()) {
        std::string lowerQuery = query;
        std::transform(lowerQuery.begin(), lowerQuery.end(), lowerQuery.begin(), ::tolower);
        
        for (size_t i = 0; i < documents.size(); ++i) {
            std::string lowerContent = documents[i].content;
            std::transform(lowerContent.begin(), lowerContent.end(), lowerContent.begin(), ::tolower);
            
            // Check if any query term appears in document content
            bool found = false;
            for (const auto& term : queryTerms) {
                if (lowerContent.find(term) != std::string::npos) {
                    candidateDocIds.insert(static_cast<int>(i));
                    found = true;
                    break;
                }
            }
            // Also check original query string
            if (!found && lowerContent.find(lowerQuery) != std::string::npos) {
                candidateDocIds.insert(static_cast<int>(i));
            }
        }
    }
    
    if (candidateDocIds.empty()) {
        return results;
    }
    
    // Convert set to vector for TF-IDF ranking
    std::vector<int> candidates(candidateDocIds.begin(), candidateDocIds.end());
    
    // Rank documents by TF-IDF (but don't filter zero scores - show all matches)
    std::vector<std::pair<int, double>> ranked = tfidf->rank(queryTerms, candidates);
    
    // If TF-IDF returns empty but we have candidates, use simple frequency scoring
    if (ranked.empty() && !candidates.empty()) {
        // Simple scoring: count how many query terms appear in document
        for (int docId : candidates) {
            if (docId >= 0 && docId < static_cast<int>(documents.size())) {
                const Document& doc = documents[docId];
                int matchCount = 0;
                std::string lowerContent = doc.content;
                std::transform(lowerContent.begin(), lowerContent.end(), lowerContent.begin(), ::tolower);
                
                for (const auto& term : queryTerms) {
                    if (lowerContent.find(term) != std::string::npos) {
                        matchCount++;
                    }
                }
                
                if (matchCount > 0) {
                    ranked.push_back({docId, static_cast<double>(matchCount)});
                }
            }
        }
        // Sort by match count
        std::sort(ranked.begin(), ranked.end(),
                  [](const std::pair<int, double>& a, const std::pair<int, double>& b) {
                      return a.second > b.second;
                  });
    }
    
    // Generate QueryResult objects with snippets
    for (const auto& pair : ranked) {
        int docId = pair.first;
        double score = pair.second;
        
        if (docId >= 0 && docId < static_cast<int>(documents.size())) {
            const Document& doc = documents[docId];
            std::string snippet = generateSnippet(doc, queryTerms[0]);
            
            results.push_back(QueryResult(docId, score, snippet, doc.filename));
        }
    }
    
    return results;
}

std::vector<std::string> SearchEngine::getSuggestions(const std::string& prefix) {
    return trie.prefixMatch(prefix);
}

const Document& SearchEngine::getDocument(int docId) const {
    static Document emptyDoc;
    if (docId >= 0 && docId < static_cast<int>(documents.size())) {
        return documents[docId];
    }
    return emptyDoc;
}

size_t SearchEngine::getDocumentCount() const {
    return documents.size();
}

void SearchEngine::clear() {
    documents.clear();
    delete tfidf;
    tfidf = nullptr;
    index.clear();
    // Note: Trie will be rebuilt when documents are added
}

