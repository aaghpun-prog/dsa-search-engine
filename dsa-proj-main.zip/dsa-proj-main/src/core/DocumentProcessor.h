#ifndef DOCUMENT_PROCESSOR_H
#define DOCUMENT_PROCESSOR_H

#include "../../include/types.h"
#include <string>
#include <vector>
#include <unordered_set>

/**
 * @brief Processes and tokenizes documents for indexing and analysis
 * 
 * Handles file loading, text normalization, tokenization, and sentence extraction.
 */
class DocumentProcessor {
private:
    std::unordered_set<std::string> stopwords; // Common stopwords to filter

    /**
     * @brief Initialize common English stopwords
     */
    void initializeStopwords();

    /**
     * @brief Check if word is a stopword
     * @param word Word to check
     * @return True if stopword
     */
    bool isStopword(const std::string& word) const;

    /**
     * @brief Normalize a word (lowercase, remove punctuation)
     * @param word Input word
     * @return Normalized word
     */
    std::string normalizeWord(const std::string& word) const;

public:
    DocumentProcessor();

    /**
     * @brief Load a text or PDF file and create a Document object
     * @param filepath Path to .txt or .pdf file
     * @param docId Unique document ID
     * @return Document object, or empty Document if load fails
     */
    Document loadFile(const std::string& filepath, int docId);

    /**
     * @brief Extract text from a PDF file
     * @param filepath Path to PDF file
     * @return Extracted text content, or empty string if extraction fails
     */
    std::string extractTextFromPDF(const std::string& filepath) const;

    /**
     * @brief Check if file is a PDF based on extension
     * @param filepath File path
     * @return True if file has .pdf extension
     */
    bool isPDFFile(const std::string& filepath) const;

    /**
     * @brief Clean extracted PDF text by removing metadata and artifacts
     * @param text Raw extracted text
     * @return Cleaned text with only readable content
     */
    std::string cleanPDFText(const std::string& text) const;

    /**
     * @brief Check if a line contains readable text (not PDF metadata)
     * @param line Text line to check
     * @return True if line appears to be readable text
     */
    bool isReadableText(const std::string& line) const;

    /**
     * @brief Tokenize text into words
     * @param text Input text
     * @return Vector of normalized tokens
     */
    std::vector<std::string> tokenize(const std::string& text) const;

    /**
     * @brief Tokenize search query (doesn't filter stopwords)
     * @param text Search query text
     * @return Vector of normalized tokens
     */
    std::vector<std::string> tokenizeQuery(const std::string& text) const;

    /**
     * @brief Extract sentences from text
     * @param text Input text
     * @return Vector of sentences
     */
    std::vector<std::string> extractSentences(const std::string& text) const;

    /**
     * @brief Build term frequency map from tokens
     * @param tokens Tokenized words
     * @return Map of term -> frequency
     */
    std::unordered_map<std::string, int> buildTermFreq(const std::vector<std::string>& tokens) const;

    /**
     * @brief Process document: tokenize and extract sentences
     * @param doc Document to process (modifies in place)
     */
    void processDocument(Document& doc);
};

#endif // DOCUMENT_PROCESSOR_H

