#include "KeywordExtractor.h"
#include <algorithm>

std::vector<std::string> KeywordExtractor::extract(const Document& doc, int topK) {
    return extract(doc.termFreq, topK);
}

std::vector<std::string> KeywordExtractor::extract(const std::unordered_map<std::string, int>& termFreq, int topK) {
    if (termFreq.empty()) {
        return std::vector<std::string>();
    }
    
    // Use min-heap to maintain top K keywords
    std::priority_queue<KeywordPair, std::vector<KeywordPair>, std::greater<KeywordPair>> minHeap;
    
    for (const auto& pair : termFreq) {
        KeywordPair kp;
        kp.freq = pair.second;
        kp.keyword = pair.first;
        
        if (static_cast<int>(minHeap.size()) < topK) {
            minHeap.push(kp);
        } else if (kp.freq > minHeap.top().freq) {
            minHeap.pop();
            minHeap.push(kp);
        }
    }
    
    // Extract keywords from heap
    std::vector<KeywordPair> keywords;
    while (!minHeap.empty()) {
        keywords.push_back(minHeap.top());
        minHeap.pop();
    }
    
    // Sort by frequency descending
    std::sort(keywords.begin(), keywords.end(),
              [](const KeywordPair& a, const KeywordPair& b) {
                  if (a.freq != b.freq) {
                      return a.freq > b.freq;
                  }
                  return a.keyword < b.keyword;
              });
    
    // Extract just the keywords
    std::vector<std::string> result;
    for (const auto& kp : keywords) {
        result.push_back(kp.keyword);
    }
    
    return result;
}

