#include "Summarizer.h"
#include <sstream>

std::string Summarizer::summarize(const Document& doc, int numSentences) {
    if (doc.sentences.empty()) {
        return "No sentences found in document.";
    }
    
    return summarize(doc.sentences, numSentences);
}

std::string Summarizer::summarize(const std::vector<std::string>& sentences, int numSentences) {
    if (sentences.empty()) {
        return "No sentences to summarize.";
    }
    
    // Use TextRank to score sentences
    std::vector<std::pair<int, double>> ranked = textRank.compute(sentences);
    
    // Extract top N sentences (maintain original order in summary)
    int count = std::min(numSentences, static_cast<int>(ranked.size()));
    
    // Collect indices of top sentences
    std::vector<int> topIndices;
    for (int i = 0; i < count; ++i) {
        topIndices.push_back(ranked[i].first);
    }
    
    // Sort indices to maintain document order
    std::sort(topIndices.begin(), topIndices.end());
    
    // Build summary
    std::ostringstream summary;
    for (size_t i = 0; i < topIndices.size(); ++i) {
        if (i > 0) {
            summary << " ";
        }
        summary << sentences[topIndices[i]];
    }
    
    return summary.str();
}

