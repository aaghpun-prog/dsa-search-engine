#include "TopicGraph.h"
#include <sstream>
#include <algorithm>
#include <queue>

bool TopicGraph::coOccur(const std::string& topic1, const std::string& topic2,
                         const std::vector<Document>& documents) const {
    if (topic1 == topic2) {
        return false;
    }
    
    std::string lower1 = topic1;
    std::string lower2 = topic2;
    std::transform(lower1.begin(), lower1.end(), lower1.begin(), ::tolower);
    std::transform(lower2.begin(), lower2.end(), lower2.begin(), ::tolower);
    
    // Check if both topics appear in at least one document
    for (const auto& doc : documents) {
        bool hasTopic1 = false;
        bool hasTopic2 = false;
        
        for (const auto& token : doc.tokens) {
            std::string lowerToken = token;
            std::transform(lowerToken.begin(), lowerToken.end(), lowerToken.begin(), ::tolower);
            
            if (lowerToken == lower1) {
                hasTopic1 = true;
            }
            if (lowerToken == lower2) {
                hasTopic2 = true;
            }
            
            if (hasTopic1 && hasTopic2) {
                return true;
            }
        }
    }
    
    return false;
}

void TopicGraph::build(const std::vector<Document>& documents, const std::vector<std::string>& keywords) {
    graph.clear();
    
    if (documents.empty() || keywords.empty()) {
        return;
    }
    
    // Initialize all keywords as nodes
    for (const auto& keyword : keywords) {
        graph[keyword] = std::vector<std::string>();
    }
    
    // Build edges based on co-occurrence
    for (size_t i = 0; i < keywords.size(); ++i) {
        for (size_t j = i + 1; j < keywords.size(); ++j) {
            if (coOccur(keywords[i], keywords[j], documents)) {
                // Add edge in both directions (undirected graph)
                graph[keywords[i]].push_back(keywords[j]);
                graph[keywords[j]].push_back(keywords[i]);
            }
        }
    }
}

std::vector<std::string> TopicGraph::getNeighbors(const std::string& topic) const {
    auto it = graph.find(topic);
    if (it != graph.end()) {
        return it->second;
    }
    return std::vector<std::string>();
}

std::vector<std::string> TopicGraph::getTopics() const {
    std::vector<std::string> topics;
    for (const auto& pair : graph) {
        topics.push_back(pair.first);
    }
    return topics;
}

std::string TopicGraph::visualize() const {
    if (graph.empty()) {
        return "No graph data available.";
    }
    
    std::ostringstream oss;
    oss << "Topic Relationship Graph:\n";
    oss << "========================\n\n";
    
    // BFS-based visualization starting from topics with most connections
    std::unordered_set<std::string> visited;
    std::vector<std::string> topics = getTopics();
    
    // Sort by number of neighbors (descending)
    std::sort(topics.begin(), topics.end(),
              [this](const std::string& a, const std::string& b) {
                  return graph.at(a).size() > graph.at(b).size();
              });
    
    // Display graph structure
    for (const auto& topic : topics) {
        if (visited.find(topic) != visited.end()) {
            continue;
        }
        
        // Use BFS to traverse connected component
        std::queue<std::string> q;
        q.push(topic);
        visited.insert(topic);
        
        oss << "[" << topic << "]\n";
        
        while (!q.empty()) {
            std::string current = q.front();
            q.pop();
            
            const auto& neighbors = graph.at(current);
            if (!neighbors.empty()) {
                for (const auto& neighbor : neighbors) {
                    oss << "  -> " << neighbor << "\n";
                    if (visited.find(neighbor) == visited.end()) {
                        visited.insert(neighbor);
                        q.push(neighbor);
                    }
                }
            }
        }
        
        oss << "\n";
    }
    
    // Statistics
    oss << "Graph Statistics:\n";
    oss << "  Total Topics: " << graph.size() << "\n";
    
    int totalEdges = 0;
    for (const auto& pair : graph) {
        totalEdges += static_cast<int>(pair.second.size());
    }
    totalEdges /= 2; // Undirected graph
    
    oss << "  Total Connections: " << totalEdges << "\n";
    
    return oss.str();
}

void TopicGraph::clear() {
    graph.clear();
}

