#include "QuestionGenerator.h"
#include <algorithm>
#include <random>
#include <sstream>
#include <cctype>

std::vector<Question> QuestionGenerator::generateFillBlank(const std::vector<std::string>& sentences,
                                                            const std::vector<std::string>& keywords,
                                                            int numQuestions) const {
    std::vector<Question> questions;
    
    if (sentences.empty() || keywords.empty()) {
        return questions;
    }
    
    int count = 0;
    for (const auto& sentence : sentences) {
        if (count >= numQuestions) break;
        
        // Find sentence containing a keyword
        std::string lowerSentence = sentence;
        std::transform(lowerSentence.begin(), lowerSentence.end(), lowerSentence.begin(), ::tolower);
        
        for (const auto& keyword : keywords) {
            std::string lowerKeyword = keyword;
            std::transform(lowerKeyword.begin(), lowerKeyword.end(), lowerKeyword.begin(), ::tolower);
            
            size_t pos = lowerSentence.find(lowerKeyword);
            if (pos != std::string::npos) {
                // Replace keyword with blank
                std::string question = sentence;
                size_t actualPos = question.find(keyword, pos);
                if (actualPos != std::string::npos) {
                    question.replace(actualPos, keyword.length(), "______");
                    
                    Question q("fill_blank", question, keyword);
                    questions.push_back(q);
                    count++;
                    break;
                }
            }
        }
    }
    
    return questions;
}

std::vector<Question> QuestionGenerator::generateTrueFalse(const std::vector<std::string>& sentences,
                                                            int numQuestions) const {
    std::vector<Question> questions;
    
    if (sentences.empty()) {
        return questions;
    }
    
    int count = 0;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 1);
    
    for (const auto& sentence : sentences) {
        if (count >= numQuestions) break;
        
        // Generate true statement
        Question trueQ("true_false", sentence, "True");
        questions.push_back(trueQ);
        count++;
        
        if (count >= numQuestions) break;
        
        // Generate false statement by negating or modifying
        std::string falseSentence = sentence;
        
        // Simple negation rules
        if (falseSentence.find("is ") != std::string::npos) {
            size_t pos = falseSentence.find("is ");
            falseSentence.replace(pos, 3, "is not ");
        } else if (falseSentence.find("are ") != std::string::npos) {
            size_t pos = falseSentence.find("are ");
            falseSentence.replace(pos, 4, "are not ");
        } else if (falseSentence.find("can ") != std::string::npos) {
            size_t pos = falseSentence.find("can ");
            falseSentence.replace(pos, 4, "cannot ");
        } else {
            // Add "not" after first verb if possible
            falseSentence = "It is not true that " + falseSentence;
        }
        
        Question falseQ("true_false", falseSentence, "False");
        questions.push_back(falseQ);
        count++;
    }
    
    // Shuffle for variety
    std::shuffle(questions.begin(), questions.end(), gen);
    
    if (static_cast<int>(questions.size()) > numQuestions) {
        questions.resize(numQuestions);
    }
    
    return questions;
}

std::string QuestionGenerator::sentenceToQuestion(const std::string& sentence) const {
    std::string question = sentence;
    
    // Remove period
    if (!question.empty() && question.back() == '.') {
        question.pop_back();
    }
    
    // Convert to question form
    std::string lower = question;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
    
    if (lower.find("is ") == 0) {
        question = "What " + question;
    } else if (lower.find("are ") == 0) {
        question = "What " + question;
    } else if (lower.find("defines") != std::string::npos || lower.find("definition") != std::string::npos) {
        question = "What is the definition? " + question;
    } else if (lower.find("algorithm") != std::string::npos || lower.find("method") != std::string::npos) {
        question = "Explain: " + question;
    } else {
        question = "What is " + question + "?";
    }
    
    return question;
}

std::vector<Question> QuestionGenerator::generateShortAnswer(const std::vector<std::string>& sentences,
                                                              int numQuestions) const {
    std::vector<Question> questions;
    
    if (sentences.empty()) {
        return questions;
    }
    
    int count = 0;
    for (const auto& sentence : sentences) {
        if (count >= numQuestions) break;
        
        std::string question = sentenceToQuestion(sentence);
        Question q("short_answer", question, sentence); // Answer is the original sentence
        questions.push_back(q);
        count++;
    }
    
    return questions;
}

std::vector<std::string> QuestionGenerator::generateDistractors(const std::string& correctAnswer,
                                                                 const std::unordered_map<std::string, int>& termFreq,
                                                                 int numDistractors) const {
    std::vector<std::string> distractors;
    
    if (termFreq.empty()) {
        return distractors;
    }
    
    // Get sorted terms by frequency
    std::vector<std::pair<std::string, int>> sortedTerms;
    for (const auto& pair : termFreq) {
        if (pair.first != correctAnswer && pair.first.length() > 2) {
            sortedTerms.push_back(pair);
        }
    }
    
    std::sort(sortedTerms.begin(), sortedTerms.end(),
              [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
                  return a.second > b.second;
              });
    
    // Select distractors
    for (size_t i = 0; i < sortedTerms.size() && static_cast<int>(distractors.size()) < numDistractors; ++i) {
        distractors.push_back(sortedTerms[i].first);
    }
    
    return distractors;
}

std::vector<Question> QuestionGenerator::generateMCQ(const std::vector<std::string>& sentences,
                                                     const std::vector<std::string>& keywords,
                                                     const std::unordered_map<std::string, int>& termFreq,
                                                     int numQuestions) const {
    std::vector<Question> questions;
    
    if (sentences.empty() || keywords.empty()) {
        return questions;
    }
    
    int count = 0;
    for (size_t i = 0; i < keywords.size() && count < numQuestions; ++i) {
        const std::string& keyword = keywords[i];
        
        // Find a sentence containing this keyword
        std::string questionText;
        for (const auto& sentence : sentences) {
            std::string lowerSentence = sentence;
            std::transform(lowerSentence.begin(), lowerSentence.end(), lowerSentence.begin(), ::tolower);
            
            std::string lowerKeyword = keyword;
            std::transform(lowerKeyword.begin(), lowerKeyword.end(), lowerKeyword.begin(), ::tolower);
            
            if (lowerSentence.find(lowerKeyword) != std::string::npos) {
                questionText = sentenceToQuestion(sentence);
                break;
            }
        }
        
        if (questionText.empty()) {
            questionText = "What is " + keyword + "?";
        }
        
        // Generate options
        std::vector<std::string> options;
        options.push_back(keyword); // Correct answer first
        
        std::vector<std::string> distractors = generateDistractors(keyword, termFreq, 3);
        for (const auto& distractor : distractors) {
            options.push_back(distractor);
        }
        
        // Shuffle options
        std::random_device rd;
        std::mt19937 gen(rd());
        std::shuffle(options.begin(), options.end(), gen);
        
        Question q("mcq", questionText, options, keyword);
        questions.push_back(q);
        count++;
    }
    
    return questions;
}

std::vector<Question> QuestionGenerator::generate(const Document& doc, const std::string& type, int numQuestions) {
    std::vector<Question> allQuestions;
    
    if (doc.sentences.empty()) {
        return allQuestions;
    }
    
    // Extract keywords
    std::vector<std::string> keywords = extractor.extract(doc, 20);
    
    if (type == "fill_blank" || type == "all") {
        auto fillBlankQs = generateFillBlank(doc.sentences, keywords, numQuestions);
        allQuestions.insert(allQuestions.end(), fillBlankQs.begin(), fillBlankQs.end());
    }
    
    if (type == "true_false" || type == "all") {
        auto tfQs = generateTrueFalse(doc.sentences, numQuestions);
        allQuestions.insert(allQuestions.end(), tfQs.begin(), tfQs.end());
    }
    
    if (type == "short_answer" || type == "all") {
        auto saQs = generateShortAnswer(doc.sentences, numQuestions);
        allQuestions.insert(allQuestions.end(), saQs.begin(), saQs.end());
    }
    
    if (type == "mcq" || type == "all") {
        auto mcqQs = generateMCQ(doc.sentences, keywords, doc.termFreq, numQuestions);
        allQuestions.insert(allQuestions.end(), mcqQs.begin(), mcqQs.end());
    }
    
    return allQuestions;
}

