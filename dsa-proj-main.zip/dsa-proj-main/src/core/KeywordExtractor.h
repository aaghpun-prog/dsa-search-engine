#ifndef KEYWORD_EXTRACTOR_H
#define KEYWORD_EXTRACTOR_H

#include "../../include/types.h"
#include <string>
#include <vector>
#include <queue>
#include <unordered_map>

/**
 * @brief Extracts top keywords using frequency analysis and min-heap
 * 
 * Uses priority queue (min-heap) to efficiently find top K keywords.
 */
class KeywordExtractor {
private:
    /**
     * @brief Pair for min-heap: (frequency, keyword)
     */
    struct KeywordPair {
        int freq;
        std::string keyword;
        
        bool operator>(const KeywordPair& other) const {
            if (freq != other.freq) {
                return freq > other.freq; // Min-heap: smaller frequency first
            }
            return keyword < other.keyword;
        }
    };

public:
    KeywordExtractor() = default;
    ~KeywordExtractor() = default;

    /**
     * @brief Extract top K keywords from a document
     * @param doc Document to extract keywords from
     * @param topK Number of top keywords to extract (default: 10)
     * @return Vector of keywords, sorted by frequency (descending)
     */
    std::vector<std::string> extract(const Document& doc, int topK = 10);

    /**
     * @brief Extract top K keywords from term frequency map
     * @param termFreq Term frequency map
     * @param topK Number of top keywords to extract (default: 10)
     * @return Vector of keywords, sorted by frequency (descending)
     */
    std::vector<std::string> extract(const std::unordered_map<std::string, int>& termFreq, int topK = 10);
};

#endif // KEYWORD_EXTRACTOR_H

