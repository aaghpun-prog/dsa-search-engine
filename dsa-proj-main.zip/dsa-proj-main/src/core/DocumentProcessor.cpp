#include "DocumentProcessor.h"
#include <fstream>
#include <sstream>
#include <cctype>
#include <algorithm>
#include <cstdlib>
#include <QProcess>
#include <QFileInfo>
#include <QStringList>

DocumentProcessor::DocumentProcessor() {
    initializeStopwords();
}

void DocumentProcessor::initializeStopwords() {
    // Common English stopwords
    std::vector<std::string> words = {
        "a", "an", "and", "are", "as", "at", "be", "by", "for", "from",
        "has", "he", "in", "is", "it", "its", "of", "on", "that", "the",
        "to", "was", "will", "with", "the", "this", "but", "they", "have",
        "had", "what", "said", "each", "which", "their", "time", "if",
        "up", "out", "many", "then", "them", "these", "so", "some", "her",
        "would", "make", "like", "into", "him", "has", "two", "more",
        "very", "after", "words", "long", "than", "first", "been", "call",
        "who", "oil", "its", "now", "find", "down", "day", "did", "get",
        "come", "made", "may", "part", "over", "new", "sound", "take",
        "only", "little", "work", "know", "place", "year", "live", "me",
        "back", "give", "most", "very", "after", "thing", "our", "just",
        "name", "good", "sentence", "man", "think", "say", "great", "where",
        "through", "much", "before", "line", "right", "too", "mean", "old",
        "any", "same", "tell", "boy", "follow", "came", "want", "show",
        "also", "around", "form", "three", "small", "set", "put", "end",
        "does", "another", "well", "large", "must", "big", "even", "such",
        "because", "turn", "here", "why", "ask", "went", "men", "read",
        "need", "land", "different", "home", "us", "move", "try", "kind",
        "hand", "picture", "again", "change", "off", "play", "spell", "air",
        "away", "animal", "house", "point", "page", "letter", "mother", "answer",
        "found", "study", "still", "learn", "should", "America", "world", "high",
        "every", "near", "add", "food", "between", "own", "below", "country",
        "plant", "last", "school", "father", "keep", "tree", "never", "start",
        "city", "earth", "eye", "light", "thought", "head", "under", "story",
        "saw", "left", "don't", "few", "while", "along", "might", "close",
        "something", "seem", "next", "hard", "open", "example", "begin", "life",
        "always", "those", "both", "paper", "together", "got", "group", "often",
        "run", "important", "until", "children", "side", "feet", "car", "mile",
        "night", "walk", "white", "sea", "began", "grow", "took", "river",
        "four", "carry", "state", "once", "book", "hear", "stop", "without",
        "second", "later", "miss", "idea", "enough", "eat", "face", "watch",
        "far", "Indian", "really", "almost", "let", "above", "girl", "sometimes",
        "mountain", "cut", "young", "talk", "soon", "list", "song", "leave",
        "family", "body"
    };
    
    for (const auto& word : words) {
        stopwords.insert(word);
    }
}

bool DocumentProcessor::isStopword(const std::string& word) const {
    return stopwords.find(word) != stopwords.end();
}

std::string DocumentProcessor::normalizeWord(const std::string& word) const {
    std::string normalized;
    for (char c : word) {
        if (std::isalnum(c)) {
            normalized += std::tolower(c);
        }
    }
    return normalized;
}

std::vector<std::string> DocumentProcessor::tokenize(const std::string& text) const {
    std::vector<std::string> tokens;
    std::stringstream ss(text);
    std::string word;
    
    while (ss >> word) {
        std::string normalized = normalizeWord(word);
        if (!normalized.empty() && !isStopword(normalized)) {
            tokens.push_back(normalized);
        }
    }
    
    return tokens;
}

std::vector<std::string> DocumentProcessor::tokenizeQuery(const std::string& text) const {
    std::vector<std::string> tokens;
    std::stringstream ss(text);
    std::string word;
    
    while (ss >> word) {
        std::string normalized = normalizeWord(word);
        // Don't filter stopwords in queries - allow searching for common words
        if (!normalized.empty()) {
            tokens.push_back(normalized);
        }
    }
    
    return tokens;
}

std::vector<std::string> DocumentProcessor::extractSentences(const std::string& text) const {
    std::vector<std::string> sentences;
    std::string current;
    
    for (char c : text) {
        current += c;
        
        // Sentence endings: . ! ?
        if (c == '.' || c == '!' || c == '?') {
            // Trim whitespace
            std::string trimmed;
            bool startFound = false;
            for (char ch : current) {
                if (!startFound && std::isspace(ch)) {
                    continue;
                }
                startFound = true;
                trimmed += ch;
            }
            
            // Remove trailing whitespace
            while (!trimmed.empty() && std::isspace(trimmed.back())) {
                trimmed.pop_back();
            }
            
            if (!trimmed.empty()) {
                sentences.push_back(trimmed);
            }
            current.clear();
        }
    }
    
    // Add remaining text if any
    if (!current.empty()) {
        std::string trimmed;
        bool startFound = false;
        for (char ch : current) {
            if (!startFound && std::isspace(ch)) {
                continue;
            }
            startFound = true;
            trimmed += ch;
        }
        while (!trimmed.empty() && std::isspace(trimmed.back())) {
            trimmed.pop_back();
        }
        if (!trimmed.empty()) {
            sentences.push_back(trimmed);
        }
    }
    
    return sentences;
}

std::unordered_map<std::string, int> DocumentProcessor::buildTermFreq(const std::vector<std::string>& tokens) const {
    std::unordered_map<std::string, int> termFreq;
    for (const auto& token : tokens) {
        termFreq[token]++;
    }
    return termFreq;
}

bool DocumentProcessor::isPDFFile(const std::string& filepath) const {
    if (filepath.length() < 4) {
        return false;
    }
    std::string ext = filepath.substr(filepath.length() - 4);
    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
    return ext == ".pdf";
}

bool DocumentProcessor::isReadableText(const std::string& line) const {
    if (line.empty() || line.length() < 5) {
        return false;
    }
    
    // PDF structure markers to filter out - be very aggressive
    std::string lowerLine = line;
    std::transform(lowerLine.begin(), lowerLine.end(), lowerLine.begin(), ::tolower);
    
    // Filter out ALL PDF structure elements
    if (lowerLine.find("<<") != std::string::npos ||
        lowerLine.find(">>") != std::string::npos ||
        lowerLine.find("/type") != std::string::npos ||
        lowerLine.find("/font") != std::string::npos ||
        lowerLine.find("/flags") != std::string::npos ||
        lowerLine.find("/ascent") != std::string::npos ||
        lowerLine.find("/descent") != std::string::npos ||
        lowerLine.find("/stemv") != std::string::npos ||
        lowerLine.find("/capheight") != std::string::npos ||
        lowerLine.find("/italicangle") != std::string::npos ||
        lowerLine.find("/fontbbox") != std::string::npos ||
        lowerLine.find("/fontfile") != std::string::npos ||
        lowerLine.find("endobj") != std::string::npos ||
        lowerLine.find(" obj") != std::string::npos ||
        lowerLine.find("endstream") != std::string::npos ||
        lowerLine.find("stream") != std::string::npos ||
        lowerLine.find("xref") != std::string::npos ||
        lowerLine.find("trailer") != std::string::npos ||
        lowerLine.find("%pdf") != std::string::npos ||
        lowerLine.find("%%") != std::string::npos ||
        lowerLine.find(" 0 r") != std::string::npos ||
        lowerLine.find(" 0 r>>") != std::string::npos ||
        (lowerLine.find("/") != std::string::npos && 
         (lowerLine.find(" r") != std::string::npos || lowerLine[0] == '/')) ||
        (line.length() < 8 && !std::isalpha(line[0]))) {
        return false;
    }
    
    // Check if line has meaningful alphabetic content
    int alphaCount = 0;
    int totalChars = 0;
    bool hasMultipleWords = false;
    int wordCount = 0;
    
    std::string currentWord;
    for (char c : line) {
        if (!std::isspace(c)) {
            totalChars++;
            currentWord += c;
            if (std::isalpha(c)) {
                alphaCount++;
            }
        } else {
            if (currentWord.length() >= 2) {
                wordCount++;
                if (wordCount >= 2) hasMultipleWords = true;
            }
            currentWord.clear();
        }
    }
    // Check last word
    if (currentWord.length() >= 2) {
        wordCount++;
        if (wordCount >= 2) hasMultipleWords = true;
    }
    
    // Must have multiple words or be a substantial single word
    if (totalChars < 5) return false;
    if (wordCount == 0) return false;
    
    // Calculate alphabetic ratio
    double alphaRatio = static_cast<double>(alphaCount) / totalChars;
    
    // For very short lines, require high alphabetic ratio
    if (totalChars < 15) {
        if (alphaRatio < 0.7) return false; // Very short lines must be mostly alphabetic
    } else {
        // Longer lines: at least 40% alphabetic and multiple words preferred
        if (alphaRatio < 0.4) return false;
        if (!hasMultipleWords && totalChars < 20) return false; // Short lines need multiple words
    }
    
    // Reject lines that are mostly numbers or symbols
    int digitCount = 0;
    for (char c : line) {
        if (std::isdigit(c)) digitCount++;
    }
    double digitRatio = static_cast<double>(digitCount) / totalChars;
    if (digitRatio > 0.5 && alphaRatio < 0.3) return false; // Mostly numbers
    
    return true;
}

std::string DocumentProcessor::cleanPDFText(const std::string& text) const {
    if (text.empty()) {
        return "";
    }
    
    std::stringstream ss(text);
    std::string line;
    std::vector<std::string> cleanLines;
    int consecutiveMetadataLines = 0;
    
    while (std::getline(ss, line)) {
        // Remove leading/trailing whitespace
        while (!line.empty() && std::isspace(line.front())) {
            line.erase(0, 1);
        }
        while (!line.empty() && std::isspace(line.back())) {
            line.pop_back();
        }
        
        // Skip empty lines
        if (line.empty()) continue;
        
        // Only keep readable lines
        if (isReadableText(line)) {
            cleanLines.push_back(line);
            consecutiveMetadataLines = 0;
        } else {
            consecutiveMetadataLines++;
            // If we see too many metadata lines in a row, we're probably in PDF structure section
            if (consecutiveMetadataLines > 5 && cleanLines.size() > 10) {
                // We've collected enough readable content, skip the rest
                break;
            }
        }
    }
    
    // If we have very few clean lines, the extraction probably failed
    if (cleanLines.size() < 3) {
        return ""; // Too little readable content
    }
    
    // Join clean lines
    std::string result;
    for (size_t i = 0; i < cleanLines.size(); ++i) {
        result += cleanLines[i];
        if (i < cleanLines.size() - 1) {
            result += "\n";
        }
    }
    
    return result;
}

std::string DocumentProcessor::extractTextFromPDF(const std::string& filepath) const {
    std::string rawText;
    bool usedPdfToText = false;
    
    // Try using pdftotext command via QProcess (preferred method)
    QProcess process;
    QString pdfPath = QString::fromStdString(filepath);
    process.start("pdftotext", QStringList() << "-layout" << "-nopgbrk" << "-enc" << "UTF-8" << 
                  pdfPath << "-");
    
    if (process.waitForFinished(30000) && process.exitCode() == 0) { // 30 second timeout
        QByteArray output = process.readAllStandardOutput();
        rawText = std::string(output.constData(), output.length());
        usedPdfToText = true;
    }
    
    // If pdftotext failed or not available, try textutil on macOS as fallback
    // Note: textutil may extract raw PDF structure, so we'll clean it aggressively
    if (rawText.empty() || (!usedPdfToText && rawText.length() < 50)) {
        #ifdef Q_OS_MACOS
        QProcess macProcess;
        macProcess.start("textutil", QStringList() << "-convert" << "txt" << 
                        "-stdout" << pdfPath);
        if (macProcess.waitForFinished(30000) && macProcess.exitCode() == 0) {
            QByteArray output = macProcess.readAllStandardOutput();
            rawText = std::string(output.constData(), output.length());
        }
        #endif
    }
    
    if (rawText.empty()) {
        return ""; // Extraction failed
    }
    
    // Clean the extracted text to remove PDF artifacts
    std::string cleaned = cleanPDFText(rawText);
    
    // Require minimum readable content (at least 100 characters)
    if (cleaned.length() < 100) {
        // Not enough readable content - PDF probably doesn't have extractable text
        // or extraction method failed
        return "";
    }
    
    return cleaned;
}

Document DocumentProcessor::loadFile(const std::string& filepath, int docId) {
    std::string content;
    
    // Check if it's a PDF file
    if (isPDFFile(filepath)) {
        content = extractTextFromPDF(filepath);
        if (content.empty() || content.length() < 100) {
            // Return empty document if extraction failed
            // The GUI will show appropriate error message
            return Document(); // Extraction failed or got mostly empty/metadata content
        }
    } else {
        // Regular text file
        std::ifstream file(filepath);
        if (!file.is_open()) {
            return Document();
        }
        
        content.assign((std::istreambuf_iterator<char>(file)),
                       std::istreambuf_iterator<char>());
        file.close();
    }
    
    Document doc(docId, filepath, content);
    processDocument(doc);
    
    return doc;
}

void DocumentProcessor::processDocument(Document& doc) {
    // Extract sentences
    doc.sentences = extractSentences(doc.content);
    
    // Tokenize and build term frequency
    doc.tokens = tokenize(doc.content);
    doc.termFreq = buildTermFreq(doc.tokens);
}

